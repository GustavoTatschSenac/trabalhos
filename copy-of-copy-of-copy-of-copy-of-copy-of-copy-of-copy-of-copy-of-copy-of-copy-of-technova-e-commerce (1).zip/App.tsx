
import React, { useEffect } from 'react';
import { HashRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Home } from './pages/Home';
import { Marketplace } from './pages/Marketplace';
import { StoreBuilder } from './pages/StoreBuilder';
import { UserStore } from './pages/UserStore';
import { ProductDetails } from './pages/ProductDetails';
import { Login } from './pages/Login';
import { Cart } from './pages/Cart';
import { Checkout } from './pages/Checkout';
import { AffiliateDashboard } from './pages/AffiliateDashboard';
import { UserDashboard } from './pages/UserDashboard';
import { AdminDashboard } from './pages/AdminDashboard';
import { AuthProvider, useAuth } from './context/AuthContext';
import { CartProvider } from './context/CartContext';
import { StoreProvider } from './context/StoreContext';
import { AIAssistant } from './components/AIAssistant';

const AffiliateTracker = () => {
    const location = useLocation();
    const { updateAffiliateStats } = useAuth();

    useEffect(() => {
        const params = new URLSearchParams(location.search);
        const ref = params.get('ref');
        if (ref) {
            sessionStorage.setItem('technova_ref', ref);
            updateAffiliateStats(1, 0, 0); 
        }
    }, [location, updateAffiliateStats]);

    return null;
};

function App() {
  return (
    <AuthProvider>
      <StoreProvider>
        <CartProvider>
          <Router>
            <AffiliateTracker />
            <div className="flex flex-col min-h-screen">
              <Navbar />
              <main className="flex-grow bg-slate-50">
                <Routes>
                  <Route path="/" element={<Home />} />
                  <Route path="/marketplace" element={<Marketplace />} />
                  <Route path="/my-store" element={<StoreBuilder />} />
                  <Route path="/store/:id" element={<UserStore />} />
                  <Route path="/shop" element={<Marketplace />} /> {/* Atualizado para apontar para Marketplace */}
                  <Route path="/product/:id" element={<ProductDetails />} />
                  <Route path="/login" element={<Login />} />
                  <Route path="/cart" element={<Cart />} />
                  <Route path="/checkout" element={<Checkout />} />
                  <Route path="/affiliate" element={<AffiliateDashboard />} />
                  <Route path="/user-dashboard" element={<UserDashboard />} />
                  <Route path="/admin" element={<AdminDashboard />} />
                </Routes>
              </main>
              <Footer />
              <AIAssistant />
            </div>
          </Router>
        </CartProvider>
      </StoreProvider>
    </AuthProvider>
  );
}

export default App;
