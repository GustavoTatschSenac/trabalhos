
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://wmteuotkrraehbkqdvdr.supabase.co';
// Utilizando a chave fornecida. 
// Nota: Chaves padrão do Supabase geralmente começam com "ey...", mas utilizaremos a string exata fornecida.
const supabaseKey = 'sb_publishable_kqItwhRiVVzA1xMFsDDw1A_vfdeGij9';

export const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: {
    persistSession: true, // Garante que a sessão seja salva no localStorage
    autoRefreshToken: true, // Atualiza o token automaticamente em segundo plano
    detectSessionInUrl: true, // Detecta links de login mágicos ou recuperação de senha
  }
});
