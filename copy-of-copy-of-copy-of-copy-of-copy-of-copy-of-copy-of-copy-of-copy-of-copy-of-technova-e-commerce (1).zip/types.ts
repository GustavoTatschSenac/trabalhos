
export interface Product {
  id: number | string;
  name: string;
  price: number;
  oldPrice?: number;
  category: string;
  image: string;
  description: string;
  rating: number;
  badge?: string;
  storeId?: string;
  status?: 'active' | 'draft' | 'out_of_stock';
}

export interface Coupon {
  id: string;
  code: string;
  discountPercent: number;
  status: 'active' | 'expired';
  usageCount: number;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface AffiliateStat {
  clicks: number;
  sales: number;
  earnings: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  isAffiliate: boolean;
  affiliateCode?: string;
  balance: number;
  storeId?: string;
  orders?: Order[];
  affiliateStats?: AffiliateStat;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  totalSpent: number; // Calculado
  lastOrderDate: string; // Calculado
  status: 'active' | 'blocked';
  role?: string;
}

export interface AdminLog {
  id: string;
  type: 'error' | 'info' | 'warning' | 'webhook';
  message: string;
  timestamp: string;
}

export interface WebhookConfig {
  id: string;
  event: 'order.created' | 'product.updated' | 'inventory.low';
  url: string;
  status: 'active' | 'inactive';
}

export interface Store {
  id: string;
  ownerId: string;
  name: string;
  description: string;
  themeColor: string;
  bannerImage?: string;
  logo?: string;
  layout?: 'grid' | 'list';
  products: Product[];
  createdAt: string;
  visits: number;
  sales: number;
}

export interface Order {
  id: string;
  items: CartItem[];
  total: number;
  date: string;
  status: 'Processing' | 'Shipped' | 'Delivered' | 'Cancelled';
  paymentMethod: 'Credit Card' | 'Pix' | 'Boleto';
  customerName?: string;
}