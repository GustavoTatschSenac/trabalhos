import React from 'react';
import { Facebook, Twitter, Instagram, Mail, Phone } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-dark text-slate-300 py-10 border-t border-slate-800 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* About */}
          <div>
            <h3 className="text-white text-lg font-bold mb-4">TechNova</h3>
            <p className="text-sm text-slate-400">
              Líder em vendas de tecnologia, oferecendo os melhores produtos com os melhores preços. Inovação e qualidade em um só lugar.
            </p>
          </div>

          {/* Links */}
          <div>
            <h3 className="text-white text-lg font-bold mb-4">Links Úteis</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#/shop" className="hover:text-primary transition-colors">Loja</a></li>
              <li><a href="#/affiliate" className="hover:text-primary transition-colors">Seja um Afiliado</a></li>
              <li><a href="#/user-dashboard" className="hover:text-primary transition-colors">Meus Pedidos</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Política de Privacidade</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white text-lg font-bold mb-4">Contato</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center"><Mail className="h-4 w-4 mr-2" /> suporte@technova.com</li>
              <li className="flex items-center"><Phone className="h-4 w-4 mr-2" /> (11) 99999-9999</li>
              <li>Av. Paulista, 1000 - São Paulo, SP</li>
            </ul>
          </div>

          {/* Social */}
          <div>
            <h3 className="text-white text-lg font-bold mb-4">Redes Sociais</h3>
            <div className="flex space-x-4">
              <a href="#" className="hover:text-primary transition-colors"><Facebook /></a>
              <a href="#" className="hover:text-primary transition-colors"><Twitter /></a>
              <a href="#" className="hover:text-primary transition-colors"><Instagram /></a>
            </div>
          </div>

        </div>
        <div className="border-t border-slate-800 mt-8 pt-8 text-center text-sm text-slate-500">
          &copy; {new Date().getFullYear()} TechNova E-Commerce. Todos os direitos reservados.
        </div>
      </div>
    </footer>
  );
};