
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingCart, User, Menu, X, Cpu, Store as StoreIcon, ShoppingBag, ShieldCheck } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

export const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { itemCount } = useCart();
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav className="bg-dark text-white sticky top-0 z-50 shadow-lg border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <Cpu className="h-8 w-8 text-primary" />
            <span className="font-bold text-xl tracking-wider">TechNova</span>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-6">
              <Link to="/" className="hover:text-primary transition-colors px-3 py-2 rounded-md text-sm font-medium">Início</Link>
              <Link to="/marketplace" className="hover:text-primary transition-colors px-3 py-2 rounded-md text-sm font-medium flex items-center">
                <ShoppingBag className="w-4 h-4 mr-1" /> Marketplace
              </Link>
              <Link to="/my-store" className="bg-white/10 hover:bg-white/20 transition-colors px-3 py-2 rounded-md text-sm font-bold flex items-center text-primary-300 border border-white/10">
                <StoreIcon className="w-4 h-4 mr-1" /> Crie sua Loja
              </Link>
              <Link to="/affiliate" className="hover:text-primary transition-colors px-3 py-2 rounded-md text-sm font-medium">Afiliado</Link>
              <Link to="/admin" className="hover:text-primary transition-colors px-3 py-2 rounded-md text-sm font-medium flex items-center text-red-400">
                <ShieldCheck className="w-4 h-4 mr-1" /> Admin
              </Link>
            </div>
          </div>

          {/* Right Side Icons */}
          <div className="hidden md:flex items-center space-x-6">
            <Link to="/cart" className="relative p-2 hover:text-primary transition-colors">
              <ShoppingCart className="h-6 w-6" />
              {itemCount > 0 && (
                <span className="absolute top-0 right-0 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {itemCount}
                </span>
              )}
            </Link>

            {user ? (
              <div className="relative group">
                <button className="flex items-center space-x-1 hover:text-primary focus:outline-none">
                    <User className="h-6 w-6" />
                    <span className="text-sm">{user.name}</span>
                </button>
                <div className="absolute right-0 mt-2 w-48 bg-white text-black rounded-md shadow-lg py-1 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                    <Link to="/user-dashboard" className="block px-4 py-2 text-sm hover:bg-slate-100">Minha Conta</Link>
                    <Link to="/my-store" className="block px-4 py-2 text-sm hover:bg-slate-100 text-primary font-bold">Gerenciar Loja</Link>
                    <Link to="/admin" className="block px-4 py-2 text-sm hover:bg-slate-100 text-red-500">Administração</Link>
                    <button onClick={handleLogout} className="block w-full text-left px-4 py-2 text-sm hover:bg-slate-100 text-red-600">Sair</button>
                </div>
              </div>
            ) : (
              <Link to="/login" className="bg-primary hover:bg-indigo-600 px-4 py-2 rounded-md text-sm font-medium transition-colors">
                Entrar
              </Link>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="-mr-2 flex md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="bg-slate-800 p-2 rounded-md text-gray-400 hover:text-white hover:bg-slate-700 focus:outline-none">
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-slate-900 pb-4">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <Link to="/" onClick={() => setIsOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium hover:bg-slate-800 hover:text-primary">Início</Link>
            <Link to="/marketplace" onClick={() => setIsOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium hover:bg-slate-800 hover:text-primary">Marketplace</Link>
            <Link to="/my-store" onClick={() => setIsOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium hover:bg-slate-800 text-primary font-bold">Crie sua Loja</Link>
            <Link to="/affiliate" onClick={() => setIsOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium hover:bg-slate-800 hover:text-primary">Afiliado</Link>
            <Link to="/admin" onClick={() => setIsOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium hover:bg-slate-800 text-red-400">Admin</Link>
            <Link to="/cart" onClick={() => setIsOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium hover:bg-slate-800 hover:text-primary">Carrinho ({itemCount})</Link>
            {user ? (
                <>
                 <Link to="/user-dashboard" onClick={() => setIsOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium hover:bg-slate-800 hover:text-primary">Minha Conta</Link>
                 <button onClick={() => {handleLogout(); setIsOpen(false);}} className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-red-500 hover:bg-slate-800">Sair</button>
                </>
            ) : (
                <Link to="/login" onClick={() => setIsOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium hover:bg-slate-800 hover:text-primary">Entrar / Cadastrar</Link>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};
