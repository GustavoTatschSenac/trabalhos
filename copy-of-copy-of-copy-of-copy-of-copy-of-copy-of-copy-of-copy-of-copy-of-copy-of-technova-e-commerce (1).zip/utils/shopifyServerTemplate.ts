export const shopifyServerCode = `
/**
 * SERVER-SIDE INTEGRATION CODE (Node.js + Express)
 * 
 * Este código deve ser rodado em um servidor separado (ex: Heroku, AWS, DigitalOcean).
 * Ele gerencia a autenticação segura e os Webhooks da Shopify em Tempo Real.
 */

require('dotenv').config();
const express = require('express');
const crypto = require('crypto');
const axios = require('axios');
const bodyParser = require('body-parser');
const mongoose = require('mongoose'); // Exemplo com MongoDB

const app = express();
const PORT = process.env.PORT || 3000;

// Configurações
const SHOPIFY_SECRET = process.env.SHOPIFY_WEBHOOK_SECRET;
const ACCESS_TOKEN = process.env.SHOPIFY_ACCESS_TOKEN;
const SHOP_URL = process.env.SHOPIFY_SHOP_URL; // ex: minha-loja.myshopify.com

// Conexão Banco de Dados (Exemplo)
mongoose.connect(process.env.MONGODB_URI);
const ProductSchema = new mongoose.Schema({
    shopifyId: String,
    title: String,
    price: Number,
    inventory: Number
});
const ProductModel = mongoose.model('Product', ProductSchema);

// Middleware para validar HMAC da Shopify (Segurança Crítica)
const verifyShopifyWebhook = (req, res, buf) => {
    const signature = req.headers['x-shopify-hmac-sha256'];
    const digest = crypto
        .createHmac('sha256', SHOPIFY_SECRET)
        .update(buf, 'utf8')
        .digest('base64');

    if (signature !== digest) {
        console.error('⚠️ Request invalido: HMAC validation failed');
        throw new Error('Forbidden');
    }
};

// Usar body-parser raw para verificação do HMAC
app.use(bodyParser.json({ verify: verifyShopifyWebhook }));

// --- WEBHOOKS (Tempo Real) ---

// 1. Produto Criado ou Atualizado
app.post('/webhook/products/update', async (req, res) => {
    try {
        const product = req.body;
        console.log('📦 Produto atualizado:', product.title);

        await ProductModel.findOneAndUpdate(
            { shopifyId: product.id },
            {
                title: product.title,
                price: product.variants[0].price,
                inventory: product.variants[0].inventory_quantity
            },
            { upsert: true }
        );

        res.status(200).send('OK');
    } catch (error) {
        console.error('Erro ao processar produto:', error);
        res.status(500).send('Error');
    }
});

// 2. Pedido Criado
app.post('/webhook/orders/create', async (req, res) => {
    const order = req.body;
    console.log('💰 Novo pedido recebido:', order.id, 'Valor:', order.total_price);
    // Lógica para salvar pedido no seu sistema...
    res.status(200).send('OK');
});

// 3. Estoque Atualizado
app.post('/webhook/inventory/update', async (req, res) => {
    console.log('📊 Estoque atualizado');
    // Lógica de sync de estoque...
    res.status(200).send('OK');
});

// --- API MANUAL SYNC ---

app.get('/api/sync/products', async (req, res) => {
    try {
        const response = await axios.get(\`https://\${SHOP_URL}/admin/api/2024-01/products.json\`, {
            headers: { 'X-Shopify-Access-Token': ACCESS_TOKEN }
        });
        
        const products = response.data.products;
        // Salvar todos no banco...
        res.json({ success: true, count: products.length });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.listen(PORT, () => console.log(\`🚀 Servidor de Integração rodando na porta \${PORT}\`));
`;