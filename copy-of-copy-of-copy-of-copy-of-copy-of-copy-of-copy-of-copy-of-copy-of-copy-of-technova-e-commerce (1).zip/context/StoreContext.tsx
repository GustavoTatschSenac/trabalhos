
import React, { createContext, useContext, useState, useEffect } from 'react';
import { Store, Product, Coupon } from '../types';
import { useAuth } from './AuthContext';
import { supabase } from '../lib/supabase';
import { PRODUCTS } from '../constants'; // Importar dados mockados para seeding

interface StoreContextType {
  userStore: Store | null;
  stores: Store[];
  loading: boolean;
  createStore: (name: string, description: string, themeColor: string) => Promise<void>;
  updateStoreSettings: (settings: Partial<Store>) => Promise<void>;
  addProduct: (product: Omit<Product, 'id' | 'storeId' | 'rating'>) => Promise<void>;
  updateProduct: (productId: string | number, updates: Partial<Product>) => Promise<void>;
  deleteProduct: (productId: string | number) => Promise<void>;
  getStoreById: (storeId: string) => Store | undefined;
  getAllProducts: () => Product[];
  seedDatabase: () => Promise<void>;
  coupons: Coupon[];
  fetchCoupons: () => Promise<void>;
  createCoupon: (code: string, discount: number) => Promise<void>;
  deleteCoupon: (id: string) => Promise<void>;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [stores, setStores] = useState<Store[]>([]);
  const [userStore, setUserStore] = useState<Store | null>(null);
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [loading, setLoading] = useState(true);

  // Função para buscar dados
  const fetchData = async () => {
    try {
      // Supabase Join: Busca lojas e seus produtos
      const { data, error } = await supabase
        .from('stores')
        .select(`
          *,
          products (*)
        `);

      if (error) {
        if (error.code !== 'PGRST204') {
             console.error('Erro ao buscar dados:', error.message);
        }
        throw error;
      }

      if (data) {
        // Mapear snake_case para camelCase
        const mappedStores: Store[] = data.map((s: any) => ({
          id: s.id,
          ownerId: s.owner_id,
          name: s.name,
          description: s.description,
          themeColor: s.theme_color,
          visits: s.visits,
          sales: s.sales,
          createdAt: s.created_at,
          products: s.products.map((p: any) => ({
            id: p.id,
            storeId: p.store_id,
            name: p.name,
            price: p.price,
            oldPrice: p.old_price,
            category: p.category,
            image: p.image,
            description: p.description,
            rating: p.rating,
            badge: p.badge,
            status: p.status
          }))
        }));
        setStores(mappedStores);
      }
    } catch (err: any) {
      console.error('Erro de conexão com Supabase:', err.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchCoupons = async () => {
      const { data } = await supabase.from('coupons').select('*');
      if (data) {
          setCoupons(data.map((c: any) => ({
              id: c.id,
              code: c.code,
              discountPercent: c.discount_percent,
              status: c.status,
              usageCount: c.usage_count
          })));
      }
  };

  useEffect(() => {
    fetchData();
    fetchCoupons();

    // Realtime Subscriptions
    const channel = supabase
      .channel('public:stores')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'stores' }, fetchData)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'products' }, fetchData)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'coupons' }, fetchCoupons)
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // Sincronizar a loja do usuário atual
  useEffect(() => {
    if (user && stores.length > 0) {
      const myStore = stores.find(s => s.ownerId === user.id);
      setUserStore(myStore || null);
    } else {
      setUserStore(null);
    }
  }, [user, stores]);

  const createStore = async (name: string, description: string, themeColor: string) => {
    if (!user) return;

    const { error } = await supabase.from('stores').insert([{
      owner_id: user.id,
      name,
      description,
      theme_color: themeColor,
      visits: 0,
      sales: 0
    }]);

    if (error) {
        console.error("Erro ao criar loja:", error);
        alert(`Erro ao criar loja: ${error.message}`);
    } else {
        await fetchData(); // Forçar atualização
    }
  };

  const updateStoreSettings = async (settings: Partial<Store>) => {
    if (!userStore) return;
    
    // Converter camelCase para snake_case para update
    const updates: any = {};
    if (settings.name) updates.name = settings.name;
    if (settings.description) updates.description = settings.description;
    if (settings.themeColor) updates.theme_color = settings.themeColor;

    const { error } = await supabase
      .from('stores')
      .update(updates)
      .eq('id', userStore.id);

    if (error) console.error("Erro ao atualizar loja:", error);
    else await fetchData();
  };

  const addProduct = async (productData: Omit<Product, 'id' | 'storeId' | 'rating'>) => {
    // If user has no store, use the first available store or seed store logic
    // For simplicity in this demo, we check userStore first
    let targetStoreId = userStore?.id;

    if (!targetStoreId && user) {
         // Fallback: Check if user owns any store even if state isn't synced yet
         const { data } = await supabase.from('stores').select('id').eq('owner_id', user.id).single();
         if (data) targetStoreId = data.id;
    }

    if (!targetStoreId) {
        alert("Você precisa criar uma loja antes de adicionar produtos.");
        return;
    }

    const dbProduct = {
      store_id: targetStoreId,
      name: productData.name,
      price: productData.price,
      description: productData.description,
      category: productData.category,
      image: productData.image,
      old_price: productData.oldPrice,
      badge: productData.badge,
      rating: 5,
      status: 'active'
    };

    const { error } = await supabase.from('products').insert([dbProduct]);
    
    if (error) {
        console.error("Erro ao adicionar produto:", error);
        alert(`Erro ao salvar: ${error.message}`);
    } else {
        await fetchData(); 
    }
  };

  const updateProduct = async (productId: string | number, updates: Partial<Product>) => {
      const dbUpdates: any = {};
      if (updates.name) dbUpdates.name = updates.name;
      if (updates.price) dbUpdates.price = updates.price;
      if (updates.category) dbUpdates.category = updates.category;
      if (updates.description) dbUpdates.description = updates.description;
      if (updates.image) dbUpdates.image = updates.image;
      if (updates.status) dbUpdates.status = updates.status;

      const { error } = await supabase
        .from('products')
        .update(dbUpdates)
        .eq('id', productId);
      
      if (error) {
          alert("Erro ao atualizar produto: " + error.message);
      } else {
          await fetchData();
      }
  };

  const deleteProduct = async (productId: string | number) => {
    const { error } = await supabase
      .from('products')
      .delete()
      .eq('id', productId);
      
    if (error) {
        console.error("Erro ao deletar produto:", error);
        alert("Erro ao deletar produto.");
    } else {
        await fetchData();
    }
  };

  const createCoupon = async (code: string, discount: number) => {
      const { error } = await supabase.from('coupons').insert({
          code: code.toUpperCase(),
          discount_percent: discount,
          status: 'active'
      });
      if (error) alert("Erro ao criar cupom: " + error.message);
      else await fetchCoupons();
  };

  const deleteCoupon = async (id: string) => {
      const { error } = await supabase.from('coupons').delete().eq('id', id);
      if (error) alert("Erro ao deletar cupom");
      else await fetchCoupons();
  };

  const getStoreById = (storeId: string) => {
    return stores.find(s => s.id === storeId);
  };

  const getAllProducts = () => {
    return stores.flatMap(store => store.products || []);
  };

  // Função para Popular o Banco de Dados (Seed)
  const seedDatabase = async () => {
    if (!user) {
        alert("Faça login para popular o banco de dados.");
        return;
    }
    
    let targetStoreId = userStore?.id;

    if (!targetStoreId) {
        const { data, error } = await supabase.from('stores').insert([{
            owner_id: user.id,
            name: "Loja TechNova Oficial",
            description: "Produtos de alta tecnologia e inovação.",
            theme_color: "#4f46e5",
            visits: 1250,
            sales: 4500
        }]).select().single();

        if (error) {
            console.error("Erro ao criar loja seed:", error);
            alert(`Erro ao criar loja inicial: ${error.message}`);
            return;
        }
        targetStoreId = data.id;
    }

    const productsToInsert = PRODUCTS.map(p => ({
        store_id: targetStoreId,
        name: p.name,
        price: p.price,
        old_price: p.oldPrice || null,
        category: p.category,
        image: p.image,
        description: p.description,
        rating: p.rating,
        badge: p.badge || null,
        status: 'active'
    }));

    const { error: prodError } = await supabase.from('products').insert(productsToInsert);
    
    if (prodError) {
        alert(`Erro ao inserir produtos: ${prodError.message}`);
    } else {
        alert("Sucesso! Banco populado.");
        await fetchData();
    }
  };

  return (
    <StoreContext.Provider value={{ 
        userStore, stores, loading, 
        createStore, updateStoreSettings, 
        addProduct, updateProduct, deleteProduct, 
        getStoreById, getAllProducts, seedDatabase,
        coupons, fetchCoupons, createCoupon, deleteCoupon
    }}>
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) throw new Error('useStore must be used within a StoreProvider');
  return context;
};
