import React, { createContext, useContext, useState, useEffect } from 'react';
import { CartItem, Product } from '../types';
import { useAuth } from './AuthContext';
import { supabase } from '../lib/supabase';

interface CartContextType {
  items: CartItem[];
  addToCart: (product: Product) => void;
  removeFromCart: (id: number | string) => void;
  updateQuantity: (id: number | string, quantity: number) => void;
  clearCart: () => void;
  total: number;
  itemCount: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [items, setItems] = useState<CartItem[]>(() => {
    try {
      const storedCart = localStorage.getItem('techNova_cart');
      return storedCart ? JSON.parse(storedCart) : [];
    } catch (error) {
      return [];
    }
  });

  // 1. Sync DB -> State (On Login)
  useEffect(() => {
    if (user) {
      const fetchCart = async () => {
        const { data, error } = await supabase
          .from('carts')
          .select('items')
          .eq('user_id', user.id)
          .single();

        if (data && data.items) {
          // Merge strategy: DB wins if conflicts, or merge arrays? 
          // Simple strategy: If local is empty, take DB. If local has items, overwrite DB (user was shopping as guest then logged in).
          if (items.length === 0) {
             setItems(data.items);
          } else {
             saveToDb(items); // Sync guest cart to DB
          }
        }
      };
      fetchCart();
    }
  }, [user]);

  // 2. Sync State -> LocalStorage (Always)
  useEffect(() => {
    localStorage.setItem('techNova_cart', JSON.stringify(items));
  }, [items]);

  // Helper to save to DB
  const saveToDb = async (newItems: CartItem[]) => {
    if (user) {
      await supabase
        .from('carts')
        .upsert({ user_id: user.id, items: newItems, updated_at: new Date() });
    }
  };

  const addToCart = (product: Product) => {
    setItems(prev => {
      const existing = prev.find(item => item.id === product.id);
      let newItems;
      if (existing) {
        newItems = prev.map(item => 
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      } else {
        newItems = [...prev, { ...product, quantity: 1 }];
      }
      saveToDb(newItems);
      return newItems;
    });
  };

  const removeFromCart = (id: number | string) => {
    setItems(prev => {
        const newItems = prev.filter(item => item.id !== id);
        saveToDb(newItems);
        return newItems;
    });
  };

  const updateQuantity = (id: number | string, quantity: number) => {
    if (quantity < 1) return;
    setItems(prev => {
        const newItems = prev.map(item => item.id === id ? { ...item, quantity } : item);
        saveToDb(newItems);
        return newItems;
    });
  };

  const clearCart = () => {
    setItems([]);
    if (user) {
        supabase.from('carts').delete().eq('user_id', user.id); // Or update to empty array
        saveToDb([]);
    }
  };

  const total = items.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const itemCount = items.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <CartContext.Provider value={{ items, addToCart, removeFromCart, updateQuantity, clearCart, total, itemCount }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) throw new Error('useCart must be used within a CartProvider');
  return context;
};