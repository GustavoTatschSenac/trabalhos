import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Order, AffiliateStat } from '../types';
import { supabase } from '../lib/supabase';
import { AuthResponse } from '@supabase/supabase-js';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<AuthResponse>;
  resetPassword: (email: string) => Promise<void>;
  logout: () => void;
  registerAffiliate: () => Promise<void>;
  userOrders: Order[];
  addOrder: (order: Order) => Promise<void>;
  affiliateStats: AffiliateStat;
  updateAffiliateStats: (clicks: number, sales: number, amount: number) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [userOrders, setUserOrders] = useState<Order[]>([]);
  const [affiliateStats, setAffiliateStats] = useState<AffiliateStat>({ clicks: 0, sales: 0, earnings: 0 });
  const [loading, setLoading] = useState(true);

  // Função auxiliar para mapear perfil do DB (snake_case) para App (camelCase)
  const mapProfileToUser = (profile: any, authUser: any): User => ({
    id: authUser.id,
    name: profile?.name || authUser.user_metadata?.full_name || authUser.email,
    email: authUser.email || '',
    isAffiliate: profile?.is_affiliate || false,
    affiliateCode: profile?.affiliate_code,
    balance: profile?.balance || 0,
    storeId: undefined, // Carregado via StoreContext se necessário
    affiliateStats: profile?.affiliate_stats || { clicks: 0, sales: 0, earnings: 0 }
  });

  const fetchUserData = async (userId: string) => {
    try {
      // 1. Buscar Perfil (com tolerância a falhas)
      const { data: profile, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      const { data: { user: authUser } } = await supabase.auth.getUser();
      
      if (authUser) {
         // Se não tiver perfil no banco (ex: falha no trigger), usa dados do Auth para evitar travamento
         setUser(mapProfileToUser(profile || {}, authUser));
         
         if (profile?.affiliate_stats) {
            setAffiliateStats(profile.affiliate_stats);
         }
      }

      // 2. Buscar Pedidos
      const { data: orders } = await supabase
        .from('orders')
        .select('*')
        .eq('user_id', userId)
        .order('date', { ascending: false });

      if (orders) {
        const mappedOrders = orders.map(o => ({
            id: o.id,
            items: o.items,
            total: o.total,
            date: o.date,
            status: o.status,
            paymentMethod: o.payment_method
        })) as Order[];
        setUserOrders(mappedOrders);
      }

    } catch (err) {
      console.error("Erro ao carregar dados do usuário:", err);
    }
  };

  useEffect(() => {
    // Verificar sessão atual
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        fetchUserData(session.user.id);
      } else {
        setLoading(false);
      }
    });

    // Escutar mudanças de Auth
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (session?.user) {
        // Pequeno delay para garantir que o Trigger do banco já criou o perfil
        setTimeout(() => fetchUserData(session.user.id), 1000);
      } else {
        setUser(null);
        setUserOrders([]);
        setAffiliateStats({ clicks: 0, sales: 0, earnings: 0 });
      }
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const login = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
  };

  const register = async (name: string, email: string, password: string) => {
    const response = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: { full_name: name }
      }
    });

    if (response.error) throw response.error;
    return response;
  };

  const resetPassword = async (email: string) => {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: window.location.origin + '/#/reset-password'
      });
      if (error) throw error;
  };

  const logout = async () => {
    await supabase.auth.signOut();
  };

  const registerAffiliate = async () => {
    if (!user) return;
    const affiliateCode = `REF-${user.id.substring(0, 5).toUpperCase()}`;
    
    const { error } = await supabase
      .from('profiles')
      .update({ is_affiliate: true, affiliate_code: affiliateCode })
      .eq('id', user.id);

    if (!error) {
      setUser(prev => prev ? { ...prev, isAffiliate: true, affiliateCode } : null);
    }
  };

  const addOrder = async (order: Order) => {
    if (!user) return;
    
    const dbOrder = {
        user_id: user.id,
        items: order.items,
        total: order.total,
        date: order.date,
        status: order.status,
        payment_method: order.paymentMethod
    };

    const { data, error } = await supabase.from('orders').insert([dbOrder]).select();
    
    if (!error && data) {
        const newOrder = {
            id: data[0].id,
            items: data[0].items,
            total: data[0].total,
            date: data[0].date,
            status: data[0].status,
            paymentMethod: data[0].payment_method
        } as Order;
        setUserOrders(prev => [newOrder, ...prev]);
    }
  };

  const updateAffiliateStats = async (clicks: number, sales: number, amount: number) => {
    if (!user) return;
    
    const newStats = {
      clicks: affiliateStats.clicks + clicks,
      sales: affiliateStats.sales + sales,
      earnings: affiliateStats.earnings + amount
    };

    const newBalance = (Number(user.balance) + amount);

    const { error } = await supabase
      .from('profiles')
      .update({ 
        balance: newBalance,
        affiliate_stats: newStats
      })
      .eq('id', user.id);

    if (!error) {
        setAffiliateStats(newStats);
        setUser(prev => prev ? { ...prev, balance: newBalance } : null);
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, resetPassword, logout, registerAffiliate, userOrders, addOrder, affiliateStats, updateAffiliateStats }}>
      {!loading && children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};