
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useStore } from '../context/StoreContext';
import { LayoutDashboard, Package, Settings, Plus, Trash2, ExternalLink, Store as StoreIcon, DollarSign, Users, BarChart3 } from 'lucide-react';

export const StoreBuilder: React.FC = () => {
  const { user } = useAuth();
  const { userStore, createStore, addProduct, deleteProduct, updateStoreSettings } = useStore();
  
  const [activeTab, setActiveTab] = useState<'dashboard' | 'products' | 'settings'>('dashboard');
  
  // Create Store Form State
  const [setupName, setSetupName] = useState('');
  const [setupDesc, setSetupDesc] = useState('');
  const [setupColor, setSetupColor] = useState('#4f46e5');

  // Add Product Form State
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [prodName, setProdName] = useState('');
  const [prodPrice, setProdPrice] = useState('');
  const [prodDesc, setProdDesc] = useState('');
  const [prodCategory, setProdCategory] = useState('');
  const [prodImage, setProdImage] = useState('https://picsum.photos/id/20/600/600');

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 px-4 text-center">
        <div className="bg-white p-10 rounded-3xl shadow-xl max-w-lg w-full">
          <div className="w-20 h-20 bg-primary/10 text-primary rounded-full flex items-center justify-center mx-auto mb-6">
            <StoreIcon className="w-10 h-10" />
          </div>
          <h1 className="text-3xl font-extrabold text-slate-900 mb-4">Crie sua Loja Virtual</h1>
          <p className="text-slate-500 mb-8 text-lg">
            Transforme suas ideias em vendas. A plataforma TechNova permite que você construa sua marca do zero.
          </p>
          <Link to="/login" className="block w-full bg-primary text-white py-4 rounded-xl font-bold text-lg hover:bg-indigo-700 transition-all shadow-lg shadow-primary/30">
            Entrar para Começar
          </Link>
        </div>
      </div>
    );
  }

  if (!userStore) {
    return (
      <div className="min-h-screen bg-slate-50 py-12 px-4">
        <div className="max-w-2xl mx-auto bg-white rounded-3xl shadow-xl overflow-hidden">
          <div className="bg-slate-900 text-white p-8 text-center">
            <h2 className="text-3xl font-bold mb-2">Bem-vindo, Empreendedor!</h2>
            <p className="text-slate-300">Vamos configurar sua nova loja em menos de 1 minuto.</p>
          </div>
          <div className="p-8 md:p-12">
            <form onSubmit={(e) => { e.preventDefault(); createStore(setupName, setupDesc, setupColor); }} className="space-y-6">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Nome da Loja</label>
                <input 
                  required 
                  type="text" 
                  value={setupName}
                  onChange={(e) => setSetupName(e.target.value)}
                  placeholder="Ex: Geek Store, Moda Tech..." 
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Descrição Curta</label>
                <input 
                  required 
                  type="text" 
                  value={setupDesc}
                  onChange={(e) => setSetupDesc(e.target.value)}
                  placeholder="O que você vende?" 
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Cor da Marca</label>
                <div className="flex gap-4 flex-wrap">
                  {['#4f46e5', '#10b981', '#ef4444', '#f59e0b', '#8b5cf6', '#ec4899', '#06b6d4'].map(color => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setSetupColor(color)}
                      className={`w-10 h-10 rounded-full border-2 transition-transform hover:scale-110 ${setupColor === color ? 'border-slate-900 scale-110 ring-2 ring-offset-2 ring-slate-200' : 'border-transparent'}`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>
              <button type="submit" className="w-full bg-primary text-white py-4 rounded-xl font-bold text-lg hover:bg-indigo-700 transition-all shadow-xl mt-6">
                Criar Minha Loja
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    addProduct({
      name: prodName,
      price: parseFloat(prodPrice),
      description: prodDesc,
      category: prodCategory,
      image: prodImage
    });
    setIsAddModalOpen(false);
    setProdName('');
    setProdPrice('');
    setProdDesc('');
    setProdCategory('');
  };

  return (
    <div className="min-h-screen bg-slate-100 flex font-sans">
      
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-slate-200 hidden md:flex flex-col sticky top-0 h-screen">
        <div className="p-6 border-b border-slate-100">
          <div className="flex items-center space-x-2 text-slate-900 mb-1">
             <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-bold" style={{ backgroundColor: userStore.themeColor }}>
                {userStore.name.substring(0, 1)}
             </div>
             <span className="font-bold truncate">{userStore.name}</span>
          </div>
          <Link to={`/store/${userStore.id}`} target="_blank" className="text-xs text-primary flex items-center hover:underline">
             Ver loja online <ExternalLink className="w-3 h-3 ml-1" />
          </Link>
        </div>
        
        <nav className="flex-1 p-4 space-y-1">
          <button onClick={() => setActiveTab('dashboard')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${activeTab === 'dashboard' ? 'bg-slate-100 text-primary' : 'text-slate-600 hover:bg-slate-50'}`}>
             <LayoutDashboard className="w-5 h-5" /> <span>Visão Geral</span>
          </button>
          <button onClick={() => setActiveTab('products')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${activeTab === 'products' ? 'bg-slate-100 text-primary' : 'text-slate-600 hover:bg-slate-50'}`}>
             <Package className="w-5 h-5" /> <span>Produtos</span>
          </button>
          <button onClick={() => setActiveTab('settings')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${activeTab === 'settings' ? 'bg-slate-100 text-primary' : 'text-slate-600 hover:bg-slate-50'}`}>
             <Settings className="w-5 h-5" /> <span>Configurações</span>
          </button>
        </nav>

        <div className="p-4 border-t border-slate-100">
           <p className="text-xs text-slate-400 text-center">Plano Profissional (Gratuito)</p>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8 overflow-y-auto h-screen">
        
        {/* Mobile Header (simplified) */}
        <div className="md:hidden mb-6 flex justify-between items-center">
           <h2 className="font-bold text-xl">{userStore.name}</h2>
           <Link to={`/store/${userStore.id}`} className="text-primary text-sm">Ver Loja</Link>
        </div>

        {activeTab === 'dashboard' && (
          <div className="space-y-8 animate-fade-in">
             <h2 className="text-2xl font-bold text-slate-900">Visão Geral</h2>
             
             {/* Stats Cards */}
             <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
               <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                 <div className="flex justify-between items-start mb-4">
                    <div className="p-3 bg-green-100 text-green-600 rounded-xl"><DollarSign className="w-6 h-6" /></div>
                    <span className="text-xs font-bold bg-green-50 text-green-700 px-2 py-1 rounded">+15%</span>
                 </div>
                 <h3 className="text-slate-500 text-sm font-medium">Vendas Totais</h3>
                 <p className="text-3xl font-extrabold text-slate-900">R$ 1.250,00</p>
               </div>
               <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                 <div className="flex justify-between items-start mb-4">
                    <div className="p-3 bg-blue-100 text-blue-600 rounded-xl"><Users className="w-6 h-6" /></div>
                 </div>
                 <h3 className="text-slate-500 text-sm font-medium">Visitantes</h3>
                 <p className="text-3xl font-extrabold text-slate-900">342</p>
               </div>
               <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                 <div className="flex justify-between items-start mb-4">
                    <div className="p-3 bg-purple-100 text-purple-600 rounded-xl"><Package className="w-6 h-6" /></div>
                 </div>
                 <h3 className="text-slate-500 text-sm font-medium">Produtos Ativos</h3>
                 <p className="text-3xl font-extrabold text-slate-900">{userStore.products.length}</p>
               </div>
             </div>

             {/* Chart Placeholder */}
             <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm min-h-[300px] flex items-center justify-center text-slate-400">
                <div className="text-center">
                   <BarChart3 className="w-12 h-12 mx-auto mb-2 opacity-50" />
                   <p>Gráfico de vendas aparecerá aqui após a primeira semana.</p>
                </div>
             </div>
          </div>
        )}

        {activeTab === 'products' && (
          <div className="animate-fade-in">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-2xl font-bold text-slate-900">Meus Produtos</h2>
              <button onClick={() => setIsAddModalOpen(true)} className="bg-primary hover:bg-indigo-700 text-white px-4 py-2 rounded-lg font-bold flex items-center transition-colors">
                <Plus className="w-5 h-5 mr-1" /> Novo Produto
              </button>
            </div>

            {userStore.products.length === 0 ? (
              <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center">
                <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                   <Package className="w-8 h-8 text-slate-400" />
                </div>
                <h3 className="text-lg font-bold text-slate-900">Nenhum produto ainda</h3>
                <p className="text-slate-500 mb-6">Comece adicionando seu primeiro item para venda.</p>
                <button onClick={() => setIsAddModalOpen(true)} className="text-primary font-bold hover:underline">Adicionar agora</button>
              </div>
            ) : (
              <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
                <table className="w-full text-left">
                  <thead className="bg-slate-50 border-b border-slate-100">
                    <tr>
                      <th className="p-4 text-xs font-bold text-slate-500 uppercase">Produto</th>
                      <th className="p-4 text-xs font-bold text-slate-500 uppercase">Preço</th>
                      <th className="p-4 text-xs font-bold text-slate-500 uppercase text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {userStore.products.map(product => (
                      <tr key={product.id} className="hover:bg-slate-50">
                        <td className="p-4 flex items-center">
                           <img src={product.image} alt="" className="w-10 h-10 rounded-lg object-cover mr-3" />
                           <div>
                               <span className="font-medium text-slate-900 block">{product.name}</span>
                               <span className="text-xs text-slate-500">{product.category}</span>
                           </div>
                        </td>
                        <td className="p-4 text-slate-900 font-bold">R$ {product.price.toFixed(2)}</td>
                        <td className="p-4 text-right">
                           <button onClick={() => deleteProduct(product.id)} className="text-red-500 hover:text-red-700 p-2 hover:bg-red-50 rounded-lg transition-colors">
                              <Trash2 className="w-4 h-4" />
                           </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="max-w-2xl animate-fade-in">
             <h2 className="text-2xl font-bold text-slate-900 mb-8">Configurações da Loja</h2>
             
             <div className="bg-white p-8 rounded-2xl border border-slate-200 space-y-6">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Nome da Loja</label>
                  <input 
                    type="text" 
                    value={userStore.name}
                    onChange={(e) => updateStoreSettings({ name: e.target.value })}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Descrição</label>
                  <input 
                    type="text" 
                    value={userStore.description}
                    onChange={(e) => updateStoreSettings({ description: e.target.value })}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Cor do Tema</label>
                  <input 
                    type="color" 
                    value={userStore.themeColor}
                    onChange={(e) => updateStoreSettings({ themeColor: e.target.value })}
                    className="h-12 w-full p-1 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer"
                  />
                </div>
             </div>
          </div>
        )}
      </main>

      {/* Add Product Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
           <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 animate-scale-in">
              <h3 className="text-xl font-bold text-slate-900 mb-4">Adicionar Novo Produto</h3>
              <form onSubmit={handleAddProduct} className="space-y-4">
                 <input required type="text" placeholder="Nome do Produto" value={prodName} onChange={e => setProdName(e.target.value)} className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary outline-none" />
                 <div className="grid grid-cols-2 gap-4">
                    <input required type="number" step="0.01" placeholder="Preço (R$)" value={prodPrice} onChange={e => setProdPrice(e.target.value)} className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary outline-none" />
                    <input required type="text" placeholder="Categoria" value={prodCategory} onChange={e => setProdCategory(e.target.value)} className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary outline-none" />
                 </div>
                 <textarea required placeholder="Descrição" value={prodDesc} onChange={e => setProdDesc(e.target.value)} className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary outline-none h-24"></textarea>
                 <input type="text" placeholder="URL da Imagem (Opcional)" value={prodImage} onChange={e => setProdImage(e.target.value)} className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary outline-none text-sm" />
                 
                 <div className="flex gap-3 mt-6">
                    <button type="button" onClick={() => setIsAddModalOpen(false)} className="flex-1 py-3 text-slate-600 font-bold hover:bg-slate-100 rounded-lg">Cancelar</button>
                    <button type="submit" className="flex-1 py-3 bg-primary text-white font-bold rounded-lg hover:bg-indigo-700">Salvar</button>
                 </div>
              </form>
           </div>
        </div>
      )}
    </div>
  );
};
