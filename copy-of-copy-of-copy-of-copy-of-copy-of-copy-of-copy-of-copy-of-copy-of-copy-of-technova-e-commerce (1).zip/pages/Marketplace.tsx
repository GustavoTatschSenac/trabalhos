
import React, { useState, useEffect, useMemo } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { PRODUCTS, CATEGORIES } from '../constants';
import { useStore } from '../context/StoreContext'; // Import Store Context
import { Filter, ShoppingCart, Star, Store as StoreIcon } from 'lucide-react';
import { useCart } from '../context/CartContext';

export const Marketplace: React.FC = () => {
  const [searchParams] = useSearchParams();
  const [selectedCategory, setSelectedCategory] = useState("Todos");
  const [searchQuery, setSearchQuery] = useState("");
  const { addToCart } = useCart();
  const { getAllProducts } = useStore(); // Get user products

  useEffect(() => {
    const cat = searchParams.get("category");
    if (cat && CATEGORIES.includes(cat)) {
      setSelectedCategory(cat);
    }
  }, [searchParams]);

  // Combine Mock Products + User Created Products
  const allProducts = useMemo(() => {
    const userProducts = getAllProducts();
    return [...PRODUCTS, ...userProducts];
  }, [getAllProducts]);

  // Derive dynamic categories from all available products
  const dynamicCategories = useMemo(() => {
      const allCats = new Set([...CATEGORIES, ...allProducts.map(p => p.category)]);
      return Array.from(allCats).sort();
  }, [allProducts]);

  const filteredProducts = allProducts.filter(product => {
    const matchesCategory = selectedCategory === "Todos" || product.category === selectedCategory;
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 min-h-screen bg-slate-50/50">
      <div className="flex flex-col md:flex-row gap-8">
        
        {/* Sidebar Filters */}
        <aside className="w-full md:w-64 flex-shrink-0">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm sticky top-24">
            <div className="flex items-center mb-6 text-slate-900 border-b border-slate-100 pb-4">
              <Filter className="w-5 h-5 mr-2 text-primary" />
              <h2 className="font-bold text-lg">Filtros</h2>
            </div>
            
            <div className="mb-6">
              <label className="text-xs font-bold text-slate-500 uppercase mb-2 block">Buscar</label>
              <input 
                type="text" 
                placeholder="Ex: Smartphone..." 
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent outline-none text-sm transition-all"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            <div>
              <h3 className="text-xs font-bold text-slate-500 uppercase mb-3">Categorias</h3>
              <ul className="space-y-1 max-h-[400px] overflow-y-auto custom-scrollbar pr-2">
                {dynamicCategories.map(category => (
                  <li key={category}>
                    <button
                      onClick={() => setSelectedCategory(category)}
                      className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors flex justify-between items-center ${
                        selectedCategory === category 
                          ? 'bg-primary text-white font-medium shadow-md shadow-primary/30' 
                          : 'text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      {category}
                      {selectedCategory === category && <div className="w-1.5 h-1.5 rounded-full bg-white"></div>}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </aside>

        {/* Product Grid */}
        <div className="flex-1">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Marketplace TechNova</h1>
            <span className="text-slate-500 text-sm font-medium bg-white px-3 py-1 rounded-full border border-slate-200 shadow-sm">
              {filteredProducts.length} produtos
            </span>
          </div>

          {filteredProducts.length === 0 ? (
            <div className="text-center py-20 bg-white rounded-xl border border-slate-200 shadow-sm">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-400">
                 <Filter className="w-8 h-8" />
              </div>
              <p className="text-slate-900 font-bold text-lg">Nenhum produto encontrado.</p>
              <p className="text-slate-500">Tente buscar por outro termo ou categoria.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map((product) => (
                <div key={product.id} className="bg-white rounded-2xl border border-slate-200 overflow-hidden hover:shadow-xl transition-all duration-300 flex flex-col group relative">
                  
                  {/* Image Area */}
                  <div className="relative h-56 overflow-hidden bg-slate-100 p-4">
                     {/* If it's a user product, clicking might go to product details or we need to handle routing carefully since mock products have ID 1-8 and user products use GUIDs */}
                    <Link to={`/product/${product.id}`} className="block w-full h-full">
                         <img src={product.image} alt={product.name} className="w-full h-full object-contain mix-blend-multiply group-hover:scale-105 transition-transform duration-500" />
                    </Link>
                    
                    {product.badge && (
                      <div className="absolute top-3 left-3 bg-primary text-white text-xs font-bold px-3 py-1 rounded-full shadow-md z-10">
                        {product.badge}
                      </div>
                    )}

                    {product.storeId && (
                         <div className="absolute top-3 right-3 bg-white/90 backdrop-blur px-2 py-1 rounded-lg text-xs font-bold text-slate-800 flex items-center shadow-sm z-10">
                            <StoreIcon className="w-3 h-3 text-purple-600 mr-1" /> Parceiro
                        </div>
                    )}
                  </div>
                  
                  <div className="p-5 flex-1 flex flex-col">
                    <div className="flex justify-between items-start mb-2">
                      <span className="text-xs text-slate-500 uppercase font-bold tracking-wider">{product.category}</span>
                      <div className="flex items-center text-xs font-bold text-slate-700">
                        <Star className="w-3 h-3 text-yellow-400 fill-yellow-400 mr-1" /> {product.rating || 'New'}
                      </div>
                    </div>
                    
                    <Link to={`/product/${product.id}`} className="font-bold text-slate-900 text-lg mb-2 hover:text-primary transition-colors line-clamp-1">
                      {product.name}
                    </Link>
                    
                    <p className="text-slate-600 text-sm mb-4 line-clamp-2 flex-1 leading-relaxed">{product.description}</p>
                    
                    <div className="mt-auto pt-4 border-t border-slate-100 flex items-end justify-between">
                      <div>
                         {product.oldPrice && (
                            <span className="text-xs text-slate-400 line-through block mb-0.5">R$ {product.oldPrice.toFixed(2)}</span>
                         )}
                         <span className="text-xl font-extrabold text-slate-900">R$ {product.price.toFixed(2)}</span>
                      </div>
                      <button 
                        onClick={() => addToCart(product)}
                        className="w-10 h-10 bg-slate-900 text-white rounded-xl flex items-center justify-center hover:bg-primary hover:scale-110 transition-all shadow-lg"
                        title="Adicionar ao Carrinho"
                      >
                        <ShoppingCart className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
