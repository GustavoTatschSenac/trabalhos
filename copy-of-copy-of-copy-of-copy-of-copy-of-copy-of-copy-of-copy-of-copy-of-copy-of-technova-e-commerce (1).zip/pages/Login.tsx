
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Lock, Mail, User, AlertCircle, Loader2, CheckCircle, ArrowRight } from 'lucide-react';

export const Login: React.FC = () => {
  const [isRegister, setIsRegister] = useState(false);
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [loading, setLoading] = useState(false);
  
  const { login, register, resetPassword } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');
    setLoading(true);

    const cleanEmail = email.trim();
    const cleanPassword = password.trim();

    try {
      if (isForgotPassword) {
        await resetPassword(cleanEmail);
        setSuccessMessage('Email de recuperação enviado! Verifique sua caixa de entrada.');
        setLoading(false);
        return;
      }

      if (isRegister) {
        if (cleanPassword.length < 6) {
             throw new Error("Password should be at least 6 characters");
        }
        const response = await register(name.trim(), cleanEmail, cleanPassword);
        
        // Verifica se o Supabase retornou usuário mas sessão nula (Email confirmation required)
        if (response.data.user && !response.data.session) {
            setSuccessMessage('Cadastro realizado! Um link de confirmação foi enviado para o seu email. Por favor, confirme antes de entrar.');
            setIsRegister(false); // Volta para tela de login
            setEmail(cleanEmail);
            setPassword('');
        } else {
            navigate('/user-dashboard');
        }
      } else {
        await login(cleanEmail, cleanPassword);
        navigate('/user-dashboard');
      }
    } catch (err: any) {
      console.error(err);
      const msg = (err.message || '').toLowerCase(); // Convertendo para minúsculas para facilitar comparação
      
      // Mapeamento de Erros do Supabase (Robustez Aumentada)
      if (msg.includes('password') && msg.includes('characters')) {
         setError('A senha deve ter pelo menos 6 caracteres.');
      } else if (msg.includes('invalid login credentials') || msg.includes('invalid login')) {
         setError('Email ou senha incorretos.');
      } else if (msg.includes('email not confirmed')) {
         setError('Email não confirmado. Por favor, verifique sua caixa de entrada.');
      } else if (msg.includes('user already registered') || msg.includes('user_already_exists')) {
         setError('Este email já está cadastrado. Tente fazer login.');
      } else if (msg.includes('valid email') || msg.includes('invalid') || msg.includes('validation failed')) {
         setError('O endereço de email é inválido.');
      } else if (msg.includes('user not found')) {
         setError('Usuário não encontrado.');
      } else if (msg.includes('rate limit')) {
         setError('Muitas tentativas. Aguarde alguns minutos.');
      } else {
         setError('Ocorreu um erro: ' + (err.message || 'Desconhecido'));
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-100 px-4 py-12">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-2xl overflow-hidden">
        <div className="bg-dark p-8 text-center relative overflow-hidden">
          <div className="absolute inset-0 bg-primary/10"></div>
          <div className="relative z-10">
            <h2 className="text-3xl font-bold text-white tracking-wider">TechNova</h2>
            <p className="text-slate-400 text-sm mt-2">
                {isForgotPassword ? 'Recuperação de Senha' : (isRegister ? 'Crie sua conta' : 'Acesse sua conta')}
            </p>
          </div>
        </div>
        
        <div className="p-8">
          {error && (
            <div className="bg-red-50 text-red-600 p-4 rounded-xl mb-6 text-sm flex items-start animate-fade-in">
              <AlertCircle className="w-5 h-5 mr-2 shrink-0 mt-0.5" /> 
              <span>{error}</span>
            </div>
          )}

          {successMessage && (
            <div className="bg-green-50 text-green-700 p-4 rounded-xl mb-6 text-sm flex items-start animate-fade-in border border-green-100">
              <CheckCircle className="w-5 h-5 mr-2 shrink-0 mt-0.5" /> 
              <span>{successMessage}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            {isRegister && !isForgotPassword && (
              <div className="relative group">
                <User className="absolute left-3 top-3.5 text-slate-400 w-5 h-5 group-focus-within:text-primary transition-colors" />
                <input 
                  type="text" 
                  placeholder="Nome Completo" 
                  className="w-full pl-10 p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary focus:bg-white focus:border-transparent outline-none transition-all"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>
            )}
            
            <div className="relative group">
              <Mail className="absolute left-3 top-3.5 text-slate-400 w-5 h-5 group-focus-within:text-primary transition-colors" />
              <input 
                type="email" 
                placeholder="Seu Email" 
                className="w-full pl-10 p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary focus:bg-white focus:border-transparent outline-none transition-all"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            {!isForgotPassword && (
                <div className="relative group">
                <Lock className="absolute left-3 top-3.5 text-slate-400 w-5 h-5 group-focus-within:text-primary transition-colors" />
                <input 
                    type="password" 
                    placeholder="Sua Senha" 
                    className="w-full pl-10 p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary focus:bg-white focus:border-transparent outline-none transition-all"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    minLength={6}
                />
                </div>
            )}

            <button 
              type="submit" 
              disabled={loading}
              className="w-full bg-primary text-white py-4 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-primary/30 flex justify-center items-center hover:-translate-y-1 active:scale-95 disabled:opacity-70 disabled:hover:translate-y-0"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : (
                  isForgotPassword ? 'Enviar Link' : (isRegister ? 'Cadastrar' : 'Entrar')
              )}
              {!loading && !isForgotPassword && <ArrowRight className="w-4 h-4 ml-2" />}
            </button>
          </form>

          <div className="mt-6 flex flex-col items-center space-y-3 text-sm">
            {!isForgotPassword && !isRegister && (
                <button 
                onClick={() => { setIsForgotPassword(true); setError(''); setSuccessMessage(''); }} 
                className="text-slate-500 hover:text-slate-800 transition-colors"
                >
                Esqueceu sua senha?
                </button>
            )}

            {isForgotPassword ? (
                <button 
                onClick={() => { setIsForgotPassword(false); setError(''); setSuccessMessage(''); }} 
                className="text-primary font-bold hover:underline"
                >
                Voltar para Login
                </button>
            ) : (
                <button 
                onClick={() => { setIsRegister(!isRegister); setError(''); setSuccessMessage(''); }} 
                className="text-primary font-bold hover:underline"
                >
                {isRegister ? 'Já tem uma conta? Faça Login' : 'Não tem conta? Cadastre-se'}
                </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
