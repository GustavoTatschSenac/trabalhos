import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { PRODUCTS } from '../constants';
import { useCart } from '../context/CartContext';
import { Star, Truck, ShieldCheck, ShoppingCart, CreditCard, ArrowLeft } from 'lucide-react';

export const ProductDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const product = PRODUCTS.find(p => p.id === Number(id));

  const [added, setAdded] = useState(false);

  if (!product) {
    return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50">
            <div className="text-center">
                <h2 className="text-2xl font-bold text-slate-900">Produto não encontrado</h2>
                <button onClick={() => navigate('/marketplace')} className="mt-4 text-primary hover:underline">Voltar para a loja</button>
            </div>
        </div>
    );
  }

  const handleAddToCart = () => {
    addToCart(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const discountPercentage = product.oldPrice 
    ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100) 
    : 0;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 min-h-screen">
      <button onClick={() => navigate(-1)} className="flex items-center text-slate-500 hover:text-primary mb-8 font-medium transition-colors">
        <ArrowLeft className="w-4 h-4 mr-2" /> Voltar
      </button>
      
      <div className="bg-white rounded-3xl shadow-xl border border-slate-200 overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
          
          {/* Image Section */}
          <div className="p-12 bg-slate-50 flex items-center justify-center relative">
             {product.badge && (
                <div className="absolute top-8 left-8 bg-primary text-white font-bold px-4 py-2 rounded-full shadow-lg z-10">
                  {product.badge}
                </div>
             )}
            <img src={product.image} alt={product.name} className="max-w-full h-auto max-h-[500px] object-contain mix-blend-multiply hover:scale-105 transition-transform duration-500" />
          </div>

          {/* Info Section */}
          <div className="p-8 md:p-12 flex flex-col bg-white">
            <div className="mb-6">
              <div className="flex justify-between items-start">
                <span className="inline-block px-3 py-1 bg-slate-100 text-slate-600 text-xs font-bold uppercase tracking-wider rounded-lg mb-4">{product.category}</span>
                <div className="flex items-center space-x-1 bg-yellow-50 px-2 py-1 rounded-lg border border-yellow-100">
                    <span className="font-bold text-slate-800 text-sm">{product.rating}</span>
                    <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                </div>
              </div>
              <h1 className="text-4xl font-extrabold text-slate-900 mb-4 leading-tight">{product.name}</h1>
            </div>

            <p className="text-slate-600 text-lg leading-relaxed mb-8">
              {product.description}
            </p>

            {/* Pricing */}
            <div className="mb-8 p-6 bg-slate-50 rounded-2xl border border-slate-100">
               {product.oldPrice && (
                   <div className="flex items-center space-x-3 mb-1">
                       <span className="text-slate-400 line-through text-lg">R$ {product.oldPrice.toFixed(2)}</span>
                       <span className="bg-green-100 text-green-700 text-xs font-bold px-2 py-1 rounded-md">
                           {discountPercentage}% OFF
                       </span>
                   </div>
               )}
               <div className="flex items-baseline space-x-2">
                   <span className="text-5xl font-extrabold text-slate-900">R$ {product.price.toFixed(2)}</span>
                   <span className="text-slate-500 font-medium">à vista</span>
               </div>
               <p className="text-slate-500 text-sm mt-2">
                   ou 12x de R$ {(product.price / 12).toFixed(2)} sem juros
               </p>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-4 mb-8">
                <button 
                  onClick={handleAddToCart}
                  className={`flex-1 py-4 rounded-xl font-bold text-lg flex items-center justify-center transition-all transform active:scale-95 shadow-lg ${
                    added 
                      ? 'bg-green-500 text-white shadow-green-500/30' 
                      : 'bg-primary text-white hover:bg-indigo-600 shadow-primary/30'
                  }`}
                >
                  {added ? (
                    <>✓ Adicionado</>
                  ) : (
                    <>
                      <ShoppingCart className="w-5 h-5 mr-2" /> Adicionar ao Carrinho
                    </>
                  )}
                </button>
            </div>

            {/* Benefits */}
            <div className="grid grid-cols-2 gap-4 pt-8 border-t border-slate-100">
              <div className="flex items-start space-x-3">
                <Truck className="w-6 h-6 text-primary shrink-0" />
                <div>
                    <h4 className="font-bold text-slate-900 text-sm">Frete Grátis</h4>
                    <p className="text-xs text-slate-500">Para todo o Brasil via PAC</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <ShieldCheck className="w-6 h-6 text-primary shrink-0" />
                <div>
                    <h4 className="font-bold text-slate-900 text-sm">Garantia Oficial</h4>
                    <p className="text-xs text-slate-500">12 meses de garantia</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <CreditCard className="w-6 h-6 text-primary shrink-0" />
                <div>
                    <h4 className="font-bold text-slate-900 text-sm">Pagamento Seguro</h4>
                    <p className="text-xs text-slate-500">Processado via Gateway Seguro</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};