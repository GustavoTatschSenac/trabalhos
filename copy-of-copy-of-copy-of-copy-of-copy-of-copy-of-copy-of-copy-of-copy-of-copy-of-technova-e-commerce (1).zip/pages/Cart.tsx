import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { Trash2, Plus, Minus, ArrowRight } from 'lucide-react';

export const Cart: React.FC = () => {
  const { items, removeFromCart, updateQuantity, total } = useCart();
  const navigate = useNavigate();

  if (items.length === 0) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center bg-slate-50 px-4">
        <h2 className="text-2xl font-bold text-slate-900 mb-4">Seu carrinho está vazio</h2>
        <p className="text-slate-500 mb-8">Parece que você ainda não adicionou nada.</p>
        <Link to="/marketplace" className="bg-primary text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition-colors">
          Explorar Produtos
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 min-h-screen">
      <h1 className="text-3xl font-bold text-slate-900 mb-8">Seu Carrinho</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        
        {/* Items List */}
        <div className="lg:col-span-2 space-y-4">
          {items.map((item) => (
            <div key={item.id} className="bg-white p-4 rounded-xl border border-slate-200 flex items-center shadow-sm">
              <img src={item.image} alt={item.name} className="w-20 h-20 object-cover rounded-lg bg-slate-100" />
              
              <div className="ml-4 flex-1">
                <h3 className="font-bold text-slate-900">{item.name}</h3>
                <p className="text-sm text-slate-500">{item.category}</p>
              </div>

              <div className="flex items-center space-x-3 mx-4">
                <button 
                  onClick={() => updateQuantity(item.id, item.quantity - 1)}
                  className="p-1 rounded-full hover:bg-slate-100 text-slate-600 disabled:opacity-50"
                  disabled={item.quantity <= 1}
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="w-8 text-center font-medium">{item.quantity}</span>
                <button 
                  onClick={() => updateQuantity(item.id, item.quantity + 1)}
                  className="p-1 rounded-full hover:bg-slate-100 text-slate-600"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>

              <div className="text-right min-w-[80px]">
                <div className="font-bold text-slate-900">R$ {(item.price * item.quantity).toFixed(2)}</div>
                <button 
                  onClick={() => removeFromCart(item.id)}
                  className="text-red-500 text-xs hover:text-red-700 mt-1 flex items-center justify-end ml-auto"
                >
                  <Trash2 className="w-3 h-3 mr-1" /> Remover
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm sticky top-24">
            <h2 className="text-xl font-bold text-slate-900 mb-6">Resumo do Pedido</h2>
            
            <div className="space-y-3 mb-6">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal</span>
                <span>R$ {total.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Frete</span>
                <span className="text-green-600 font-medium">Grátis</span>
              </div>
              <div className="border-t border-slate-100 pt-3 mt-3 flex justify-between font-bold text-lg text-slate-900">
                <span>Total</span>
                <span>R$ {total.toFixed(2)}</span>
              </div>
            </div>

            <button 
              onClick={() => navigate('/checkout')}
              className="w-full bg-primary text-white py-3 rounded-lg hover:bg-indigo-700 transition-all shadow-lg hover:shadow-primary/30 flex items-center justify-center font-bold"
            >
              Finalizar Compra <ArrowRight className="w-5 h-5 ml-2" />
            </button>

            <p className="text-xs text-center text-slate-400 mt-4">
              Compra segura. Seus dados estão protegidos.
            </p>
          </div>
        </div>

      </div>
    </div>
  );
};