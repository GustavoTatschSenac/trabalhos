import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useStore } from '../context/StoreContext';
import { Link } from 'react-router-dom';
import { Package, Clock, Database, CloudUpload } from 'lucide-react';

export const UserDashboard: React.FC = () => {
  const { user, userOrders } = useAuth();
  const { seedDatabase } = useStore();

  if (!user) {
     return <div className="p-8 text-center">Por favor, faça login.</div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 min-h-screen">
       <div className="flex justify-between items-center mb-8">
           <div>
               <h1 className="text-3xl font-bold text-slate-900 mb-2">Minha Conta</h1>
               <p className="text-slate-500">Olá, {user.name} ({user.email})</p>
           </div>
           
           {/* Botão de Admin para popular banco */}
           <button 
             onClick={seedDatabase}
             className="bg-slate-800 text-white px-4 py-2 rounded-lg flex items-center text-sm font-bold hover:bg-slate-900 transition-colors shadow-lg"
             title="Clique aqui se o site estiver vazio"
           >
             <CloudUpload className="w-4 h-4 mr-2" /> Inicializar Banco de Dados
           </button>
       </div>

       <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-8">
         <div className="p-6 border-b border-slate-100 flex items-center">
            <Package className="w-5 h-5 mr-2 text-primary" />
            <h2 className="font-bold text-lg">Meus Pedidos</h2>
         </div>

         {userOrders.length === 0 ? (
            <div className="p-8 text-center text-slate-500">
                Você ainda não fez nenhum pedido.
                <br/>
                <Link to="/marketplace" className="text-primary hover:underline mt-2 block">Ir para a loja</Link>
            </div>
         ) : (
            <div className="divide-y divide-slate-100">
                {userOrders.map(order => (
                    <div key={order.id} className="p-6 hover:bg-slate-50 transition-colors">
                        <div className="flex flex-col md:flex-row justify-between mb-4">
                            <div>
                                <span className="font-bold text-slate-900">Pedido #{order.id}</span>
                                <div className="text-sm text-slate-500 flex items-center mt-1">
                                    <Clock className="w-3 h-3 mr-1" /> {new Date(order.date).toLocaleDateString()}
                                </div>
                            </div>
                            <div className="mt-2 md:mt-0">
                                <span className="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-xs font-bold uppercase">{order.status}</span>
                            </div>
                        </div>
                        <div className="space-y-2">
                            {order.items.map((item, index) => (
                                <div key={index} className="flex justify-between text-sm text-slate-700">
                                    <span>{item.quantity}x {item.name}</span>
                                    <span>R$ {(item.price * item.quantity).toFixed(2)}</span>
                                </div>
                            ))}
                        </div>
                        <div className="mt-4 pt-4 border-t border-slate-100 flex justify-end">
                            <span className="font-bold text-lg">Total: R$ {order.total.toFixed(2)}</span>
                        </div>
                    </div>
                ))}
            </div>
         )}
       </div>
    </div>
  );
};