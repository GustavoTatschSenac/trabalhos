import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { CheckCircle, CreditCard, User as UserIcon, MapPin, QrCode, Copy, ShieldCheck, Loader2, Barcode, FileText } from 'lucide-react';
import { Order } from '../types';

export const Checkout: React.FC = () => {
  const { items, total, clearCart } = useCart();
  const { user, addOrder, updateAffiliateStats } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState<'details' | 'success'>('details');
  const [loading, setLoading] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'pix' | 'boleto'>('card');

  useEffect(() => {
    if (items.length === 0 && step !== 'success') {
      navigate('/cart');
    }
  }, [items, navigate, step]);

  const handlePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    // Simulate API processing time
    await new Promise(resolve => setTimeout(resolve, 3000));

    // Affiliate Logic Check
    const refCode = sessionStorage.getItem('technova_ref');
    if (refCode) {
        updateAffiliateStats(1, 1, total * 0.10); // 10% commission logic
    }

    let methodString: 'Credit Card' | 'Pix' | 'Boleto' = 'Credit Card';
    if (paymentMethod === 'pix') methodString = 'Pix';
    if (paymentMethod === 'boleto') methodString = 'Boleto';

    const newOrder: Order = {
        id: Math.random().toString(36).substr(2, 9).toUpperCase(),
        items: [...items],
        total: total,
        date: new Date().toISOString(),
        status: 'Processing',
        paymentMethod: methodString
    };

    if (user) {
        addOrder(newOrder);
    }

    clearCart();
    sessionStorage.removeItem('technova_ref');
    setLoading(false);
    setStep('success');
  };

  const copyPixCode = () => {
      navigator.clipboard.writeText("00020126360014BR.GOV.BCB.PIX0114+551199999999952040000530398654040.005802BR5913TechNova Ltda6009SAO PAULO62070503***6304ABCD");
      alert("Código Pix copiado!");
  };

  const copyBoletoCode = () => {
      navigator.clipboard.writeText("23790.50400 90000.120004 00000.000000 1 890000000000");
      alert("Linha digitável copiada!");
  };

  if (step === 'success') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 px-4 text-center">
        <div className="bg-white p-10 rounded-3xl shadow-xl max-w-md w-full transform transition-all animate-fade-in-up">
          <div className="w-24 h-24 bg-green-100 text-green-500 rounded-full flex items-center justify-center mx-auto mb-6 animate-bounce">
            <CheckCircle className="w-12 h-12" />
          </div>
          <h2 className="text-3xl font-extrabold text-slate-900 mb-3">Pedido Confirmado!</h2>
          <p className="text-slate-500 mb-8 text-lg">
            {paymentMethod === 'pix' && 'Seu pagamento Pix foi identificado. Em breve enviaremos o código de rastreio.'}
            {paymentMethod === 'card' && 'Pagamento aprovado com sucesso. Obrigado por comprar na TechNova.'}
            {paymentMethod === 'boleto' && 'Boleto gerado com sucesso. Aguardando a compensação bancária (1 a 3 dias úteis).'}
          </p>
          <div className="space-y-3">
             <button onClick={() => navigate('/user-dashboard')} className="w-full bg-slate-100 text-slate-700 py-3 rounded-xl font-bold hover:bg-slate-200 transition-colors">
                Ver Meus Pedidos
             </button>
             <button onClick={() => navigate('/')} className="w-full bg-primary text-white py-3 rounded-xl font-bold hover:bg-indigo-700 transition-colors shadow-lg shadow-primary/30">
                Voltar para a Loja
             </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 min-h-screen bg-slate-50">
      <h1 className="text-3xl font-bold text-slate-900 mb-8 flex items-center">
        <ShieldCheck className="mr-3 text-primary h-8 w-8" /> Finalizar Compra
      </h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Main Checkout Form */}
        <div className="lg:col-span-2">
          <form onSubmit={handlePayment} className="space-y-6">
            
            {/* Personal & Address */}
            <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
              <div className="flex items-center mb-6 pb-4 border-b border-slate-100">
                <UserIcon className="w-5 h-5 mr-3 text-primary" />
                <h2 className="font-bold text-xl text-slate-800">Dados de Entrega</h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-6">
                <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 uppercase">Nome Completo</label>
                    <input required type="text" defaultValue={user?.name} className="w-full p-3 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-primary transition-all" />
                </div>
                <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 uppercase">Email</label>
                    <input required type="email" defaultValue={user?.email} className="w-full p-3 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-primary transition-all" />
                </div>
              </div>
              
              <div className="space-y-4">
                 <div className="grid grid-cols-3 gap-4">
                    <input required type="text" placeholder="CEP" className="col-span-1 p-3 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-primary" />
                    <input required type="text" placeholder="Endereço" className="col-span-2 p-3 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-primary" />
                 </div>
                 <div className="grid grid-cols-3 gap-4">
                    <input required type="text" placeholder="Número" className="col-span-1 p-3 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-primary" />
                    <input required type="text" placeholder="Bairro" className="col-span-2 p-3 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-primary" />
                 </div>
              </div>
            </div>

            {/* Payment Section */}
            <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
              <div className="flex items-center mb-6 pb-4 border-b border-slate-100">
                <CreditCard className="w-5 h-5 mr-3 text-primary" />
                <h2 className="font-bold text-xl text-slate-800">Pagamento</h2>
              </div>
              
              {/* Method Selection */}
              <div className="flex gap-4 mb-8 overflow-x-auto pb-2">
                <button 
                    type="button" 
                    onClick={() => setPaymentMethod('card')}
                    className={`flex-1 min-w-[120px] py-4 px-4 rounded-xl border-2 flex flex-col items-center justify-center transition-all ${
                        paymentMethod === 'card' 
                        ? 'border-primary bg-primary/5 text-primary' 
                        : 'border-slate-100 bg-white text-slate-400 hover:border-slate-200'
                    }`}
                >
                    <CreditCard className="w-6 h-6 mb-2" />
                    <span className="font-bold text-sm">Cartão</span>
                </button>
                <button 
                    type="button" 
                    onClick={() => setPaymentMethod('pix')}
                    className={`flex-1 min-w-[120px] py-4 px-4 rounded-xl border-2 flex flex-col items-center justify-center transition-all ${
                        paymentMethod === 'pix' 
                        ? 'border-primary bg-primary/5 text-primary' 
                        : 'border-slate-100 bg-white text-slate-400 hover:border-slate-200'
                    }`}
                >
                    <QrCode className="w-6 h-6 mb-2" />
                    <span className="font-bold text-sm">Pix</span>
                </button>
                <button 
                    type="button" 
                    onClick={() => setPaymentMethod('boleto')}
                    className={`flex-1 min-w-[120px] py-4 px-4 rounded-xl border-2 flex flex-col items-center justify-center transition-all ${
                        paymentMethod === 'boleto' 
                        ? 'border-primary bg-primary/5 text-primary' 
                        : 'border-slate-100 bg-white text-slate-400 hover:border-slate-200'
                    }`}
                >
                    <Barcode className="w-6 h-6 mb-2" />
                    <span className="font-bold text-sm">Boleto</span>
                </button>
              </div>
              
              {/* Card Form */}
              {paymentMethod === 'card' && (
                  <div className="space-y-4 animate-fade-in">
                    <div className="relative">
                        <CreditCard className="absolute left-3 top-3.5 text-slate-400 w-5 h-5" />
                        <input required type="text" placeholder="Número do Cartão" className="w-full pl-10 p-3 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-primary" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                    <input required type="text" placeholder="Validade (MM/AA)" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-primary" />
                    <input required type="text" placeholder="CVV" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-primary" />
                    </div>
                    <input required type="text" placeholder="Nome impresso no cartão" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-primary" />
                  </div>
              )}

              {/* Pix UI */}
              {paymentMethod === 'pix' && (
                  <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 text-center animate-fade-in">
                      <p className="text-slate-600 mb-4 font-medium">Escaneie o QR Code para pagar:</p>
                      <div className="bg-white p-2 inline-block rounded-lg shadow-sm border border-slate-100 mb-4">
                        <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=ExemploPixTechNova" alt="QR Code Pix" className="w-40 h-40" />
                      </div>
                      <div className="flex items-center justify-center space-x-2 mb-2">
                          <code className="bg-white px-3 py-2 rounded border border-slate-200 text-xs text-slate-500 truncate max-w-[200px]">
                              00020126360014BR.GOV.BCB.PIX...
                          </code>
                          <button type="button" onClick={copyPixCode} className="text-primary hover:text-indigo-700 font-bold text-sm flex items-center">
                              <Copy className="w-4 h-4 mr-1" /> Copiar
                          </button>
                      </div>
                      <p className="text-xs text-slate-400">O pagamento é processado instantaneamente após o pagamento.</p>
                  </div>
              )}

              {/* Boleto UI */}
              {paymentMethod === 'boleto' && (
                  <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 animate-fade-in">
                      <div className="flex flex-col items-center text-center mb-6">
                        <div className="bg-white p-4 rounded-full mb-3 shadow-sm">
                            <FileText className="w-8 h-8 text-slate-700" />
                        </div>
                        <h3 className="font-bold text-slate-800">Pagamento com Boleto Bancário</h3>
                        <p className="text-sm text-slate-500 mt-1 max-w-xs">
                            O boleto tem prazo de compensação de 1 a 3 dias úteis. O envio será feito após a confirmação.
                        </p>
                      </div>
                      
                      <div className="bg-white p-4 rounded-lg border border-slate-200 mb-4">
                          <p className="text-xs font-bold text-slate-400 uppercase mb-2">Linha Digitável</p>
                          <div className="flex items-center space-x-2">
                              <code className="flex-1 font-mono text-sm text-slate-800 break-all bg-slate-50 p-2 rounded border border-slate-100">
                                23790.50400 90000.120004 00000.000000 1 890000000000
                              </code>
                              <button type="button" onClick={copyBoletoCode} className="bg-slate-100 hover:bg-slate-200 text-slate-700 p-2 rounded transition-colors" title="Copiar código">
                                  <Copy className="w-5 h-5" />
                              </button>
                          </div>
                      </div>

                      <div className="flex items-center justify-center space-x-6 text-xs text-slate-500">
                          <span className="flex items-center"><CheckCircle className="w-3 h-3 mr-1 text-green-500" /> Vencimento em 3 dias</span>
                          <span className="flex items-center"><CheckCircle className="w-3 h-3 mr-1 text-green-500" /> Pagável em qualquer banco</span>
                      </div>
                  </div>
              )}
            </div>

            <button 
                type="submit" 
                disabled={loading}
                className="w-full bg-primary text-white py-4 rounded-xl font-bold text-lg shadow-xl hover:bg-indigo-600 hover:shadow-primary/40 transition-all disabled:opacity-70 flex justify-center items-center transform hover:-translate-y-1"
            >
                {loading ? (
                    <>
                        <Loader2 className="w-6 h-6 mr-2 animate-spin" /> Processando...
                    </>
                ) : (
                    paymentMethod === 'boleto' 
                        ? 'Gerar Boleto' 
                        : (paymentMethod === 'pix' ? 'Confirmar Pagamento Pix' : `Pagar R$ ${total.toFixed(2)}`)
                )}
            </button>

          </form>
        </div>

        {/* Summary Sidebar */}
        <div className="lg:col-span-1">
           <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm sticky top-24">
             <h3 className="font-bold text-lg mb-6 text-slate-800 border-b border-slate-100 pb-4">Resumo do Pedido</h3>
             <div className="space-y-4 mb-6 max-h-80 overflow-y-auto custom-scrollbar pr-2">
                {items.map(item => (
                    <div key={item.id} className="flex items-start space-x-3">
                        <div className="w-12 h-12 bg-slate-100 rounded-md flex-shrink-0 overflow-hidden">
                            <img src={item.image} className="w-full h-full object-cover" alt={item.name} />
                        </div>
                        <div className="flex-1 text-sm">
                            <p className="text-slate-800 font-medium line-clamp-1">{item.name}</p>
                            <div className="flex justify-between mt-1 text-slate-500">
                                <span>Qtd: {item.quantity}</span>
                                <span>R$ {(item.price * item.quantity).toFixed(2)}</span>
                            </div>
                        </div>
                    </div>
                ))}
             </div>
             
             <div className="space-y-2 text-sm text-slate-600 border-t border-slate-100 pt-4">
                <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>R$ {total.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-green-600">
                    <span>Desconto</span>
                    <span>R$ 0,00</span>
                </div>
                <div className="flex justify-between">
                    <span>Frete</span>
                    <span className="text-green-600 font-bold">GRÁTIS</span>
                </div>
             </div>

             <div className="border-t border-slate-100 pt-4 mt-4 flex justify-between font-extrabold text-xl text-slate-900">
                <span>Total</span>
                <span>R$ {total.toFixed(2)}</span>
             </div>
             
             <div className="mt-6 bg-slate-50 p-3 rounded-lg text-xs text-slate-500 flex items-start">
                 <ShieldCheck className="w-4 h-4 mr-2 text-green-500 shrink-0" />
                 <p>Ambiente seguro. Seus dados são criptografados de ponta a ponta.</p>
             </div>
           </div>
        </div>

      </div>
    </div>
  );
};