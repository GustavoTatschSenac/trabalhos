import React from 'react';
import { Link } from 'react-router-dom';
import { PRODUCTS } from '../constants';
import { ArrowRight, Star, Truck, ShieldCheck, Headphones, Zap } from 'lucide-react';

export const Home: React.FC = () => {
  const featuredProducts = PRODUCTS.slice(0, 4);

  return (
    <div className="min-h-screen flex flex-col font-sans">
      {/* Hero Section */}
      <section className="relative bg-dark text-white overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center opacity-20"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-dark via-dark/90 to-transparent"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 py-24 lg:py-32 flex items-center">
          <div className="max-w-2xl">
            <span className="inline-block py-1 px-3 rounded-full bg-primary/20 text-primary text-sm font-bold mb-4 border border-primary/30">
              Novas Ofertas de Tecnologia
            </span>
            <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight mb-6 leading-tight">
              Inovação que <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-purple-400">Transforma</span>
            </h1>
            <p className="text-lg text-slate-300 mb-8 max-w-lg leading-relaxed">
              Encontre os gadgets mais avançados do mercado. De setups gamers a automação residencial, a TechNova é sua parceira digital.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/marketplace" className="bg-primary hover:bg-indigo-600 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all shadow-lg hover:shadow-primary/40 flex items-center justify-center">
                Comprar Agora <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
              <Link to="/affiliate" className="bg-white/10 hover:bg-white/20 backdrop-blur-sm text-white border border-white/10 px-8 py-4 rounded-xl font-bold text-lg transition-all text-center">
                Programa de Afiliados
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Banner */}
      <section className="bg-white border-b border-slate-100 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="flex items-center space-x-4 p-4 bg-slate-50 rounded-xl">
              <Truck className="w-8 h-8 text-primary" />
              <div>
                <h3 className="font-bold text-slate-900">Frete Grátis</h3>
                <p className="text-xs text-slate-500">Para compras acima de R$ 200</p>
              </div>
            </div>
            <div className="flex items-center space-x-4 p-4 bg-slate-50 rounded-xl">
              <ShieldCheck className="w-8 h-8 text-primary" />
              <div>
                <h3 className="font-bold text-slate-900">Garantia Estendida</h3>
                <p className="text-xs text-slate-500">30 dias para trocas e devoluções</p>
              </div>
            </div>
            <div className="flex items-center space-x-4 p-4 bg-slate-50 rounded-xl">
              <Headphones className="w-8 h-8 text-primary" />
              <div>
                <h3 className="font-bold text-slate-900">Suporte 24/7</h3>
                <p className="text-xs text-slate-500">Atendimento especializado</p>
              </div>
            </div>
            <div className="flex items-center space-x-4 p-4 bg-slate-50 rounded-xl">
              <Zap className="w-8 h-8 text-primary" />
              <div>
                <h3 className="font-bold text-slate-900">Entrega Flash</h3>
                <p className="text-xs text-slate-500">Receba em até 24 horas</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-end mb-12">
            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-2">Destaques da Semana</h2>
              <p className="text-slate-500">Os produtos mais desejados pelos nossos clientes.</p>
            </div>
            <Link to="/marketplace" className="text-primary hover:text-indigo-700 font-bold flex items-center hover:underline">
              Ver catálogo completo <ArrowRight className="w-4 h-4 ml-1" />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {featuredProducts.map((product) => (
              <Link to={`/product/${product.id}`} key={product.id} className="group bg-white border border-slate-200 rounded-2xl overflow-hidden hover:shadow-2xl hover:shadow-slate-200/50 transition-all duration-300 flex flex-col">
                <div className="relative h-64 overflow-hidden bg-slate-100 p-6 flex items-center justify-center">
                  <img src={product.image} alt={product.name} className="w-full h-full object-contain mix-blend-multiply group-hover:scale-110 transition-transform duration-500" />
                  {product.badge && (
                    <div className="absolute top-3 left-3 bg-primary text-white text-xs font-bold px-3 py-1 rounded-full shadow-md">
                      {product.badge}
                    </div>
                  )}
                  <div className="absolute top-3 right-3 bg-white/90 backdrop-blur px-2 py-1 rounded-lg text-xs font-bold text-slate-800 flex items-center shadow-sm">
                    <Star className="w-3 h-3 text-yellow-400 mr-1 fill-yellow-400" /> {product.rating}
                  </div>
                </div>
                <div className="p-5 flex-1 flex flex-col">
                  <p className="text-xs text-slate-500 mb-1 uppercase tracking-wide font-bold">{product.category}</p>
                  <h3 className="font-bold text-slate-900 text-lg mb-2 truncate">{product.name}</h3>
                  <div className="mt-auto">
                    {product.oldPrice && (
                      <span className="text-sm text-slate-400 line-through block">R$ {product.oldPrice.toFixed(2)}</span>
                    )}
                    <div className="flex items-center justify-between">
                      <span className="text-2xl font-bold text-slate-900">R$ {product.price.toFixed(2)}</span>
                      <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-900 group-hover:bg-primary group-hover:text-white transition-colors">
                          <ArrowRight className="w-5 h-5" />
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Categories Preview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-slate-900 mb-12 text-center">Explore por Categorias</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {['Notebooks', 'Smartphones', 'Áudio', 'Wearables'].map((cat) => (
              <Link to={`/marketplace?category=${cat}`} key={cat} className="group relative overflow-hidden rounded-2xl aspect-square">
                <div className="absolute inset-0 bg-slate-900/5 group-hover:bg-slate-900/10 transition-colors"></div>
                <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center z-10">
                    <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mb-4 shadow-lg group-hover:scale-110 transition-transform duration-300">
                        <span className="text-primary font-bold text-2xl">{cat[0]}</span>
                    </div>
                    <h3 className="font-bold text-slate-900 text-xl">{cat}</h3>
                    <span className="text-sm text-primary opacity-0 group-hover:opacity-100 transition-opacity mt-2 font-medium">Ver produtos &rarr;</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};