
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useStore } from '../context/StoreContext';
import { supabase } from '../lib/supabase';
import { 
    ShieldCheck, CloudUpload, Users, DollarSign, Package, AlertTriangle, 
    Database, LayoutDashboard, ShoppingCart, CreditCard, Settings, 
    FileText, Truck, Percent, Code, Terminal, Key, Webhook,
    ChevronRight, Search, Plus, Filter, MoreVertical, Eye, Download,
    Trash2, Edit, X, Save, Ban, CheckCircle
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { AdminLog, Product, Customer } from '../types';

export const AdminDashboard: React.FC = () => {
  const { user } = useAuth();
  const { seedDatabase, stores } = useStore();
  const [activeModule, setActiveModule] = useState('dashboard');
  const [devMode, setDevMode] = useState(false);

  // Mock Data for Admin Logs
  const logs: AdminLog[] = [
      { id: '1', type: 'error', message: 'Falha no webhook de pagamento Stripe', timestamp: '10:42 AM' },
      { id: '2', type: 'info', message: 'Backup do banco de dados realizado', timestamp: '03:00 AM' },
      { id: '3', type: 'webhook', message: 'Order.created enviado com sucesso', timestamp: '10:45 AM' },
  ];

  if (!user) {
     return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50 px-4">
            <div className="bg-white p-8 rounded-2xl shadow-xl max-w-md w-full text-center">
                <ShieldCheck className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-slate-900">Acesso Restrito</h2>
                <p className="text-slate-500 mb-6">Esta área é exclusiva para administradores da plataforma.</p>
                <Link to="/login" className="block w-full bg-slate-900 text-white py-3 rounded-lg font-bold">Fazer Login</Link>
            </div>
        </div>
     );
  }

  const renderModuleContent = () => {
      switch(activeModule) {
          case 'dashboard':
              return <DashboardOverview stores={stores} seedDatabase={seedDatabase} />;
          case 'products':
              return <ProductManagement stores={stores} />;
          case 'orders':
              return <OrderManagement />;
          case 'customers':
              return <CustomerManagement />;
          case 'marketing':
              return <MarketingManagement />;
          case 'dev':
              return <DevSettings logs={logs} devMode={devMode} setDevMode={setDevMode} />;
          default:
              return <DashboardOverview stores={stores} seedDatabase={seedDatabase} />;
      }
  };

  return (
    <div className="min-h-screen bg-slate-100 font-sans flex">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 text-white flex-shrink-0 hidden md:flex flex-col sticky top-16 h-[calc(100vh-64px)] overflow-y-auto">
          <div className="p-6 border-b border-slate-800">
              <h2 className="text-xl font-bold flex items-center"><ShieldCheck className="mr-2 text-red-500" /> Admin</h2>
              <p className="text-xs text-slate-500 mt-1">v2.4.0 • Enterprise</p>
          </div>
          
          <nav className="flex-1 p-4 space-y-1">
              <SidebarItem icon={<LayoutDashboard />} label="Dashboard" active={activeModule === 'dashboard'} onClick={() => setActiveModule('dashboard')} />
              
              <div className="pt-4 pb-2 text-xs font-bold text-slate-500 uppercase px-4">Gestão</div>
              <SidebarItem icon={<Package />} label="Produtos" active={activeModule === 'products'} onClick={() => setActiveModule('products')} />
              <SidebarItem icon={<ShoppingCart />} label="Pedidos" active={activeModule === 'orders'} onClick={() => setActiveModule('orders')} />
              <SidebarItem icon={<Users />} label="Clientes" active={activeModule === 'customers'} onClick={() => setActiveModule('customers')} />
              <SidebarItem icon={<CreditCard />} label="Pagamentos" active={false} />
              
              <div className="pt-4 pb-2 text-xs font-bold text-slate-500 uppercase px-4">Marketing</div>
              <SidebarItem icon={<Percent />} label="Cupons & Ofertas" active={activeModule === 'marketing'} onClick={() => setActiveModule('marketing')} />
              <SidebarItem icon={<FileText />} label="Relatórios" active={false} />
              
              <div className="pt-4 pb-2 text-xs font-bold text-slate-500 uppercase px-4">Sistema</div>
              <SidebarItem icon={<Settings />} label="Configurações" active={false} />
              <SidebarItem icon={<Truck />} label="Entregas" active={false} />
              <SidebarItem icon={<Code />} label="Desenvolvedor" active={activeModule === 'dev'} onClick={() => setActiveModule('dev')} />
          </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8 overflow-y-auto">
          {renderModuleContent()}
      </main>
    </div>
  );
};

const SidebarItem = ({ icon, label, active, onClick }: any) => (
    <button 
        onClick={onClick}
        className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${
            active ? 'bg-primary text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
        }`}
    >
        {React.cloneElement(icon, { className: "w-5 h-5" })}
        <span>{label}</span>
    </button>
);

// --- Modules ---

const DashboardOverview = ({ stores, seedDatabase }: any) => (
    <div className="animate-fade-in">
        <div className="flex justify-between items-center mb-8">
            <h1 className="text-2xl font-bold text-slate-900">Visão Geral</h1>
            <button onClick={seedDatabase} className="bg-slate-900 text-white px-4 py-2 rounded-lg text-sm font-bold flex items-center hover:bg-primary transition-colors">
                <CloudUpload className="w-4 h-4 mr-2" /> Resetar DB
            </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <KPICard title="Receita Total" value="R$ 145.200" trend="+12%" color="bg-green-100 text-green-600" icon={<DollarSign />} />
            <KPICard title="Pedidos" value="3,450" trend="+5%" color="bg-blue-100 text-blue-600" icon={<ShoppingCart />} />
            <KPICard title="Lojas Ativas" value={stores.length} trend="+2" color="bg-purple-100 text-purple-600" icon={<Package />} />
            <KPICard title="Clientes" value="12,500" trend="+8%" color="bg-orange-100 text-orange-600" icon={<Users />} />
        </div>
    </div>
);

const ProductManagement = ({ stores }: any) => {
    const { deleteProduct, updateProduct, addProduct } = useStore();
    const allProducts = stores.flatMap((s: any) => s.products || []);
    const [search, setSearch] = useState('');
    const [editingProduct, setEditingProduct] = useState<Product | null>(null);
    const [isAddMode, setIsAddMode] = useState(false);

    // Dropdown state logic could be complex, simplifying with a selectedId
    const [activeMenuId, setActiveMenuId] = useState<string | number | null>(null);

    const filtered = allProducts.filter((p: any) => p.name.toLowerCase().includes(search.toLowerCase()));

    const handleSave = async (e: React.FormEvent) => {
        e.preventDefault();
        if (isAddMode && editingProduct) {
             await addProduct(editingProduct);
        } else if (editingProduct) {
             await updateProduct(editingProduct.id, editingProduct);
        }
        setEditingProduct(null);
        setIsAddMode(false);
    };

    return (
        <div className="animate-fade-in">
             <div className="flex justify-between items-center mb-8">
                <h1 className="text-2xl font-bold text-slate-900">Gestão de Produtos</h1>
                <div className="flex gap-2">
                    <button onClick={() => { setIsAddMode(true); setEditingProduct({ name: '', price: 0, category: '', description: '', image: 'https://picsum.photos/200' } as any) }} className="bg-primary text-white px-4 py-2 rounded-lg text-sm font-bold flex items-center hover:bg-indigo-700">
                        <Plus className="w-4 h-4 mr-2" /> Novo Produto
                    </button>
                </div>
            </div>
            
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-visible min-h-[500px]">
                <div className="p-4 border-b border-slate-100 flex gap-4">
                    <div className="relative flex-1">
                        <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                        <input value={search} onChange={e => setSearch(e.target.value)} type="text" placeholder="Buscar produtos..." className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-primary" />
                    </div>
                </div>
                <table className="w-full text-left">
                    <thead className="bg-slate-50 text-slate-500 text-xs uppercase font-bold">
                        <tr>
                            <th className="p-4">Produto</th>
                            <th className="p-4">Categoria</th>
                            <th className="p-4">Preço</th>
                            <th className="p-4 text-center">Ações</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {filtered.map((p: any) => (
                            <tr key={p.id} className="hover:bg-slate-50">
                                <td className="p-4 flex items-center">
                                    <img src={p.image} className="w-8 h-8 rounded object-cover mr-3 bg-slate-100" alt="" />
                                    <span className="font-medium text-slate-900 line-clamp-1">{p.name}</span>
                                </td>
                                <td className="p-4 text-sm text-slate-600">{p.category}</td>
                                <td className="p-4 text-sm font-bold text-slate-900">R$ {p.price.toFixed(2)}</td>
                                <td className="p-4 text-center relative">
                                    <button onClick={() => setActiveMenuId(activeMenuId === p.id ? null : p.id)} className="text-slate-400 hover:text-slate-600 p-2 rounded-full hover:bg-slate-100">
                                        <MoreVertical className="w-4 h-4" />
                                    </button>
                                    
                                    {activeMenuId === p.id && (
                                        <div className="absolute right-8 top-8 w-32 bg-white rounded-lg shadow-xl border border-slate-100 z-50 flex flex-col py-1">
                                            <button onClick={() => { setEditingProduct(p); setIsAddMode(false); setActiveMenuId(null); }} className="px-4 py-2 text-left text-sm hover:bg-slate-50 flex items-center text-slate-700">
                                                <Edit className="w-3 h-3 mr-2" /> Editar
                                            </button>
                                            <button onClick={() => { if(window.confirm('Excluir?')) deleteProduct(p.id); setActiveMenuId(null); }} className="px-4 py-2 text-left text-sm hover:bg-red-50 flex items-center text-red-600">
                                                <Trash2 className="w-3 h-3 mr-2" /> Excluir
                                            </button>
                                        </div>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Edit Modal */}
            {editingProduct && (
                <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[100]">
                    <div className="bg-white rounded-xl p-6 w-full max-w-lg shadow-2xl">
                        <h3 className="text-lg font-bold mb-4">{isAddMode ? 'Criar Produto' : 'Editar Produto'}</h3>
                        <form onSubmit={handleSave} className="space-y-4">
                            <input required placeholder="Nome" value={editingProduct.name} onChange={e => setEditingProduct({...editingProduct, name: e.target.value})} className="w-full p-2 border rounded" />
                            <div className="grid grid-cols-2 gap-4">
                                <input required type="number" placeholder="Preço" value={editingProduct.price} onChange={e => setEditingProduct({...editingProduct, price: parseFloat(e.target.value)})} className="w-full p-2 border rounded" />
                                <input required placeholder="Categoria" value={editingProduct.category} onChange={e => setEditingProduct({...editingProduct, category: e.target.value})} className="w-full p-2 border rounded" />
                            </div>
                            <textarea placeholder="Descrição" value={editingProduct.description} onChange={e => setEditingProduct({...editingProduct, description: e.target.value})} className="w-full p-2 border rounded h-24"></textarea>
                            <input placeholder="URL Imagem" value={editingProduct.image} onChange={e => setEditingProduct({...editingProduct, image: e.target.value})} className="w-full p-2 border rounded" />
                            
                            <div className="flex justify-end gap-2 mt-4">
                                <button type="button" onClick={() => setEditingProduct(null)} className="px-4 py-2 text-slate-600">Cancelar</button>
                                <button type="submit" className="px-4 py-2 bg-primary text-white rounded font-bold">Salvar</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

const MarketingManagement = () => {
    const { coupons, createCoupon, deleteCoupon } = useStore();
    const [code, setCode] = useState('');
    const [discount, setDiscount] = useState('');

    const handleCreate = async (e: React.FormEvent) => {
        e.preventDefault();
        await createCoupon(code, Number(discount));
        setCode('');
        setDiscount('');
    };

    return (
        <div className="animate-fade-in">
             <div className="flex justify-between items-center mb-8">
                <h1 className="text-2xl font-bold text-slate-900">Marketing & Cupons</h1>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {/* Creator */}
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 h-fit">
                    <h3 className="font-bold mb-4 flex items-center"><Plus className="w-4 h-4 mr-2" /> Novo Cupom</h3>
                    <form onSubmit={handleCreate} className="space-y-4">
                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase">Código</label>
                            <input required value={code} onChange={e => setCode(e.target.value.toUpperCase())} className="w-full p-2 border rounded font-mono" placeholder="Ex: PROMO10" />
                        </div>
                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase">Desconto (%)</label>
                            <input required type="number" value={discount} onChange={e => setDiscount(e.target.value)} className="w-full p-2 border rounded" placeholder="10" />
                        </div>
                        <button type="submit" className="w-full bg-slate-900 text-white py-2 rounded font-bold">Criar Cupom</button>
                    </form>
                </div>

                {/* List */}
                <div className="md:col-span-2 bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                    <table className="w-full text-left">
                        <thead className="bg-slate-50 text-slate-500 text-xs uppercase font-bold">
                            <tr>
                                <th className="p-4">Código</th>
                                <th className="p-4">Desconto</th>
                                <th className="p-4">Status</th>
                                <th className="p-4 text-right">Ação</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {coupons.map(c => (
                                <tr key={c.id}>
                                    <td className="p-4 font-mono font-bold">{c.code}</td>
                                    <td className="p-4 text-green-600 font-bold">{c.discountPercent}% OFF</td>
                                    <td className="p-4"><span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded font-bold">{c.status}</span></td>
                                    <td className="p-4 text-right">
                                        <button onClick={() => deleteCoupon(c.id)} className="text-red-500 hover:bg-red-50 p-2 rounded">
                                            <Trash2 className="w-4 h-4" />
                                        </button>
                                    </td>
                                </tr>
                            ))}
                            {coupons.length === 0 && (
                                <tr><td colSpan={4} className="p-8 text-center text-slate-400">Nenhum cupom ativo.</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}

const CustomerManagement = () => {
    const [customers, setCustomers] = useState<Customer[]>([]);
    const [loading, setLoading] = useState(true);

    const fetchCustomers = async () => {
        setLoading(true);
        const { data } = await supabase.from('profiles').select('*');
        if (data) {
            setCustomers(data.map((p: any) => ({
                id: p.id,
                name: p.name,
                email: p.email,
                totalSpent: 0,
                lastOrderDate: '2023-01-01',
                status: p.status || 'active',
                role: p.role || 'customer'
            })));
        }
        setLoading(false);
    };

    useEffect(() => { fetchCustomers(); }, []);

    const toggleBan = async (id: string, currentStatus: string) => {
        const newStatus = currentStatus === 'active' ? 'blocked' : 'active';
        await supabase.from('profiles').update({ status: newStatus }).eq('id', id);
        fetchCustomers();
    };

    const deleteUser = async (id: string) => {
        if (!window.confirm("Isso removerá o acesso do usuário. Continuar?")) return;
        // In real app, call admin API to delete auth user. Here we delete profile.
        await supabase.from('profiles').delete().eq('id', id);
        fetchCustomers();
    }

    return (
        <div className="animate-fade-in">
             <div className="flex justify-between items-center mb-8">
                <h1 className="text-2xl font-bold text-slate-900">Gestão de Clientes</h1>
                <button onClick={fetchCustomers} className="text-primary text-sm font-bold">Atualizar</button>
            </div>
            
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                <table className="w-full text-left">
                    <thead className="bg-slate-50 text-slate-500 text-xs uppercase font-bold">
                        <tr>
                            <th className="p-4">Cliente</th>
                            <th className="p-4">Email</th>
                            <th className="p-4">Status</th>
                            <th className="p-4 text-right">Ações</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {customers.map(c => (
                            <tr key={c.id} className={c.status === 'blocked' ? 'bg-red-50' : ''}>
                                <td className="p-4 font-bold text-slate-900">{c.name}</td>
                                <td className="p-4 text-sm text-slate-600">{c.email}</td>
                                <td className="p-4">
                                    <span className={`px-2 py-1 rounded text-xs font-bold ${c.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                        {c.status.toUpperCase()}
                                    </span>
                                </td>
                                <td className="p-4 text-right flex justify-end gap-2">
                                    <button onClick={() => toggleBan(c.id, c.status)} className="p-2 hover:bg-slate-100 rounded text-slate-500" title={c.status === 'active' ? 'Banir' : 'Desbloquear'}>
                                        <Ban className="w-4 h-4" />
                                    </button>
                                    <button onClick={() => deleteUser(c.id)} className="p-2 hover:bg-red-100 rounded text-red-500" title="Excluir">
                                        <Trash2 className="w-4 h-4" />
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {loading && <div className="p-8 text-center">Carregando...</div>}
            </div>
        </div>
    );
};

const OrderManagement = () => (
    <div className="animate-fade-in text-center py-20 bg-white rounded-2xl border border-slate-200 border-dashed">
        <ShoppingCart className="w-16 h-16 mx-auto text-slate-300 mb-4" />
        <h3 className="text-xl font-bold text-slate-900">Módulo de Pedidos</h3>
        <p className="text-slate-500 max-w-md mx-auto mt-2">Visualize, edite e processe todos os pedidos do sistema. Integração com etiquetas de envio em breve.</p>
    </div>
);

const DevSettings = ({ logs, devMode, setDevMode }: any) => (
    <div className="animate-fade-in space-y-8">
        <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-slate-900">Área do Desenvolvedor</h1>
            <div className="flex items-center space-x-2 bg-white px-4 py-2 rounded-lg border border-slate-200">
                <span className={`w-3 h-3 rounded-full ${devMode ? 'bg-green-500' : 'bg-slate-300'}`}></span>
                <span className="text-sm font-bold text-slate-700">Sandbox Mode</span>
                <button onClick={() => setDevMode(!devMode)} className={`ml-2 w-10 h-5 rounded-full relative transition-colors ${devMode ? 'bg-primary' : 'bg-slate-300'}`}>
                    <span className={`absolute top-1 left-1 bg-white w-3 h-3 rounded-full transition-transform ${devMode ? 'translate-x-5' : ''}`}></span>
                </button>
            </div>
        </div>
        <div className="bg-slate-900 text-slate-300 p-6 rounded-2xl shadow-lg font-mono text-sm">
            <h3 className="font-bold text-white mb-4"><Terminal className="w-4 h-4 inline mr-2" /> Logs do Sistema</h3>
            <p>Listening for events...</p>
        </div>
    </div>
);

const KPICard = ({ title, value, trend, color, icon }: any) => (
    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div className="flex justify-between items-start mb-4">
            <div className={`p-3 rounded-xl ${color}`}>{React.cloneElement(icon, { className: "w-6 h-6" })}</div>
            <span className="text-xs font-bold bg-slate-100 text-slate-600 px-2 py-1 rounded">{trend}</span>
        </div>
        <h3 className="text-slate-500 text-sm font-medium">{title}</h3>
        <p className="text-3xl font-extrabold text-slate-900">{value}</p>
    </div>
);
