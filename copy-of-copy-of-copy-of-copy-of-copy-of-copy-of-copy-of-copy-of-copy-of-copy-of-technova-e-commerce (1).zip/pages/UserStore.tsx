
import React, { useState, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useStore } from '../context/StoreContext';
import { useCart } from '../context/CartContext';
import { ShoppingCart, ArrowLeft, Search, Filter, SlidersHorizontal } from 'lucide-react';

export const UserStore: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { getStoreById } = useStore();
  const { addToCart } = useCart();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  
  const store = getStoreById(id || '');

  // Calculate unique categories from the store's products
  const categories = useMemo(() => {
    if (!store) return [];
    const cats = new Set(store.products.map(p => p.category));
    return ['Todos', ...Array.from(cats)];
  }, [store]);

  // Filter products logic
  const filteredProducts = useMemo(() => {
    if (!store) return [];
    return store.products.filter(product => {
        const matchCategory = selectedCategory === 'Todos' || product.category === selectedCategory;
        const matchSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase());
        return matchCategory && matchSearch;
    });
  }, [store, selectedCategory, searchQuery]);

  if (!store) {
    return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50">
            <h1 className="text-2xl font-bold text-slate-900 mb-2">Loja não encontrada</h1>
            <p className="text-slate-500 mb-6">Esta loja pode ter sido removida ou o link está incorreto.</p>
            <Link to="/marketplace" className="text-primary font-bold hover:underline">Voltar para Marketplace</Link>
        </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 font-sans">
        {/* Store Header */}
        <div className="text-white pb-16 pt-24 px-4 text-center relative overflow-hidden" style={{ backgroundColor: store.themeColor }}>
            <div className="absolute inset-0 bg-black/10"></div>
            <div className="relative z-10 max-w-4xl mx-auto animate-fade-in">
                <h1 className="text-4xl md:text-6xl font-extrabold mb-4 drop-shadow-md">{store.name}</h1>
                <p className="text-lg opacity-90 max-w-xl mx-auto font-medium">{store.description}</p>
            </div>
        </div>

        {/* Navigation & Search Bar */}
        <div className="bg-white border-b border-slate-200 sticky top-16 z-40 shadow-sm">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
                <Link to="/" className="text-sm text-slate-500 hover:text-slate-900 flex items-center font-medium">
                    <ArrowLeft className="w-4 h-4 mr-1" /> Voltar
                </Link>
                
                {/* Mobile/Compact Search */}
                <div className="flex-1 max-w-md mx-4 hidden md:block">
                     <div className="relative">
                        <input 
                            type="text" 
                            placeholder="Buscar nesta loja..." 
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="w-full pl-10 pr-4 py-2 bg-slate-100 border-transparent focus:bg-white border focus:border-slate-300 rounded-full text-sm outline-none transition-all"
                        />
                        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
                     </div>
                </div>

                <div className="flex items-center space-x-4">
                   <Link to="/cart" className="text-slate-700 hover:text-slate-900 relative">
                      <ShoppingCart className="w-6 h-6" />
                   </Link>
                </div>
            </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="flex flex-col md:flex-row gap-8">
                
                {/* Sidebar Filters */}
                <aside className="w-full md:w-64 flex-shrink-0">
                    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm sticky top-36">
                        <div className="flex items-center mb-6 text-slate-900 pb-2 border-b border-slate-100">
                            <SlidersHorizontal className="w-5 h-5 mr-2" style={{ color: store.themeColor }} />
                            <h2 className="font-bold text-lg">Categorias</h2>
                        </div>
                        
                        {/* Mobile Search shows here if screen small */}
                        <div className="md:hidden mb-6">
                            <div className="relative">
                                <input 
                                    type="text" 
                                    placeholder="Buscar..." 
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                    className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none"
                                />
                                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                            </div>
                        </div>

                        <ul className="space-y-2">
                            {categories.map(cat => (
                                <li key={cat}>
                                    <button
                                        onClick={() => setSelectedCategory(cat)}
                                        className={`w-full text-left px-4 py-2.5 rounded-lg text-sm font-medium transition-all flex justify-between items-center ${
                                            selectedCategory === cat 
                                            ? 'text-white shadow-md' 
                                            : 'text-slate-600 hover:bg-slate-50'
                                        }`}
                                        style={selectedCategory === cat ? { backgroundColor: store.themeColor } : {}}
                                    >
                                        {cat}
                                        {selectedCategory === cat && <div className="w-1.5 h-1.5 rounded-full bg-white"></div>}
                                    </button>
                                </li>
                            ))}
                        </ul>
                    </div>
                </aside>

                {/* Main Content */}
                <div className="flex-1">
                    <div className="flex justify-between items-center mb-6">
                        <h2 className="text-2xl font-bold text-slate-900">Produtos</h2>
                        <span className="text-slate-500 text-sm font-medium bg-white px-3 py-1 rounded-full border border-slate-200 shadow-sm">
                          {filteredProducts.length} itens
                        </span>
                    </div>
                    
                    {filteredProducts.length === 0 ? (
                        <div className="text-center py-16 bg-white rounded-2xl border border-slate-200 border-dashed">
                            <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                                <Filter className="w-8 h-8 text-slate-300" />
                            </div>
                            <h3 className="text-lg font-bold text-slate-900 mb-1">Nenhum produto encontrado</h3>
                            <p className="text-slate-500">Tente mudar os filtros ou busque por outro termo.</p>
                            {store.products.length === 0 && (
                                <p className="text-xs text-orange-500 mt-4 font-bold">Esta loja ainda não cadastrou produtos.</p>
                            )}
                        </div>
                    ) : (
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                            {filteredProducts.map(product => (
                                <div key={product.id} className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 group border border-slate-100 flex flex-col">
                                    <div className="h-56 overflow-hidden bg-slate-100 relative p-4">
                                        <img src={product.image} alt={product.name} className="w-full h-full object-contain mix-blend-multiply group-hover:scale-105 transition-transform duration-500" />
                                        
                                        {product.badge && (
                                            <div className="absolute top-3 left-3 bg-slate-900 text-white text-xs font-bold px-3 py-1 rounded-full shadow-md z-10">
                                                {product.badge}
                                            </div>
                                        )}

                                        <button 
                                            onClick={() => addToCart(product)}
                                            className="absolute bottom-4 right-4 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-all z-20"
                                            style={{ color: store.themeColor }}
                                        >
                                            <ShoppingCart className="w-5 h-5" />
                                        </button>
                                    </div>
                                    <div className="p-5 flex-1 flex flex-col">
                                        <div className="flex justify-between items-start mb-2">
                                             <p className="text-xs text-slate-400 uppercase font-bold tracking-wider">{product.category}</p>
                                        </div>
                                        <h3 className="font-bold text-slate-900 text-lg mb-2 leading-tight group-hover:text-primary transition-colors">{product.name}</h3>
                                        <p className="text-sm text-slate-500 line-clamp-2 mb-4 leading-relaxed flex-1">{product.description}</p>
                                        
                                        <div className="mt-auto pt-4 border-t border-slate-100 flex items-center justify-between">
                                            <span className="text-xl font-extrabold text-slate-900">R$ {product.price.toFixed(2)}</span>
                                            <span className="text-xs text-slate-400">Em estoque</span>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </div>

        {/* Store Footer */}
        <footer className="bg-white border-t border-slate-200 mt-12 py-12">
            <div className="max-w-7xl mx-auto px-4 text-center">
                <h3 className="font-bold text-lg mb-2" style={{ color: store.themeColor }}>{store.name}</h3>
                <p className="text-slate-500 text-sm mb-6 max-w-md mx-auto">{store.description}</p>
                <div className="text-xs text-slate-400">
                    &copy; {new Date().getFullYear()} Todos os direitos reservados. <br/>
                    Plataforma desenvolvida por <span className="font-bold text-slate-600">TechNova</span>.
                </div>
            </div>
        </footer>
    </div>
  );
};
