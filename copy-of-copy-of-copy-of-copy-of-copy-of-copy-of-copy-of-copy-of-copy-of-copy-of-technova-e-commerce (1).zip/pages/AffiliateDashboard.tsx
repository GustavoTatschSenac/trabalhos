import React, { useState, useMemo, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useStore } from '../context/StoreContext';
import { supabase } from '../lib/supabase';
import { Link } from 'react-router-dom';
import { 
  DollarSign, MousePointer, ShoppingBag, Copy, TrendingUp, 
  LayoutDashboard, Store, Search, CheckCircle, Loader2, ExternalLink
} from 'lucide-react';

export const AffiliateDashboard: React.FC = () => {
  const { user, registerAffiliate, affiliateStats } = useAuth();
  const { getAllProducts } = useStore();
  const [activeTab, setActiveTab] = useState<'overview' | 'market'>('overview');
  const [withdrawing, setWithdrawing] = useState(false);

  // Affiliate Market Logic
  const [searchQuery, setSearchQuery] = useState('');
  const [affiliatedProducts, setAffiliatedProducts] = useState<string[]>([]);
  const [loadingAffiliations, setLoadingAffiliations] = useState(false);
  
  // Fetch real products
  const allMarketProducts = useMemo(() => {
    return getAllProducts();
  }, [getAllProducts]);

  // Load existing affiliations from DB
  useEffect(() => {
    if (user && user.isAffiliate) {
        const fetchAffiliations = async () => {
            const { data, error } = await supabase
                .from('affiliations')
                .select('product_id')
                .eq('user_id', user.id);
            
            if (data) {
                setAffiliatedProducts(data.map((r: any) => r.product_id));
            }
        };
        fetchAffiliations();
    }
  }, [user]);

  const filteredProducts = allMarketProducts.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    p.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleRequestAffiliation = async (productId: string | number) => {
    if (!user) return;
    setLoadingAffiliations(true);
    
    // Insert into DB
    const { error } = await supabase.from('affiliations').insert({
        user_id: user.id,
        product_id: productId
    });

    if (error) {
        console.error("Erro ao afiliar:", error);
        // Tratamento de erro específico para chave duplicada (já afiliado)
        if (error.code === '23505') {
            alert("Você já é afiliado deste produto!");
            // Otimista: Atualiza a lista localmente mesmo se o erro foi de duplicidade, para corrigir a UI
            setAffiliatedProducts(prev => {
                const pid = productId.toString();
                return prev.includes(pid) ? prev : [...prev, pid];
            });
        } else {
            // FIX: Ensure we don't alert [object Object] by extracting message properly
            const errorMsg = error.message || JSON.stringify(error) || "Erro desconhecido";
            alert(`Erro ao solicitar afiliação: ${errorMsg}`);
        }
    } else {
        setAffiliatedProducts(prev => [...prev, productId.toString()]);
        // alert("Afiliação realizada com sucesso!"); // Opcional
    }
    setLoadingAffiliations(false);
  };

  const generateDeepLink = (productId: string | number) => {
    const baseUrl = window.location.origin;
    // Uses hash router format
    return `${baseUrl}/#/product/${productId}?ref=${user?.affiliateCode}`;
  };

  const copyDeepLink = (link: string) => {
    navigator.clipboard.writeText(link);
    alert('Link exclusivo do produto copiado!');
  };

  const handleCopyStoreLink = () => {
    if (user?.affiliateCode) {
      const link = `${window.location.origin}/#/shop?ref=${user.affiliateCode}`;
      navigator.clipboard.writeText(link);
      alert('Link copiado!');
    }
  };

  const handleWithdraw = () => {
      setWithdrawing(true);
      setTimeout(() => {
          setWithdrawing(false);
          alert("Solicitação de saque enviada com sucesso! O valor será creditado em até 2 dias úteis.");
      }, 2000);
  };

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 px-4">
        <div className="bg-white p-8 rounded-2xl shadow-lg max-w-md w-full text-center">
            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <DollarSign className="w-8 h-8 text-slate-400" />
            </div>
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Acesso Restrito</h2>
            <p className="text-slate-500 mb-6">Faça login para acessar o painel de parceiros.</p>
            <Link to="/login" className="block w-full bg-primary text-white px-6 py-3 rounded-xl font-bold hover:bg-indigo-700">Ir para Login</Link>
        </div>
      </div>
    );
  }

  if (!user.isAffiliate) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 px-4 py-12 font-sans">
        <div className="max-w-4xl w-full bg-white rounded-3xl shadow-xl overflow-hidden flex flex-col md:flex-row">
            <div className="md:w-1/2 bg-dark text-white p-12 flex flex-col justify-center relative overflow-hidden">
                 <div className="absolute inset-0 bg-gradient-to-br from-primary/30 to-purple-600/30"></div>
                 <div className="relative z-10">
                    <h1 className="text-4xl font-extrabold mb-6">Seja um Parceiro TechNova</h1>
                    <p className="text-slate-300 text-lg mb-8">Transforme sua influência em renda. Divulgue os melhores produtos de tecnologia e ganhe por cada venda.</p>
                 </div>
            </div>
            <div className="md:w-1/2 p-12 flex flex-col justify-center items-center text-center">
                <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mb-6">
                    <DollarSign className="w-10 h-10 text-green-600" />
                </div>
                <h2 className="text-2xl font-bold text-slate-900 mb-4">Pronto para começar?</h2>
                <button 
                    onClick={registerAffiliate}
                    className="w-full bg-primary text-white py-4 rounded-xl font-bold text-lg hover:bg-indigo-700 transition-all shadow-lg shadow-primary/30"
                >
                    Ativar Painel de Afiliado
                </button>
            </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 min-h-screen">
      <div className="flex flex-col md:flex-row justify-between items-end mb-8">
        <div>
            <span className="text-primary font-bold tracking-wider uppercase text-xs mb-1 block">Área do Parceiro</span>
            <h1 className="text-3xl font-extrabold text-slate-900">Dashboard de Afiliado</h1>
            <p className="text-slate-500 mt-1">Código: <strong className="text-slate-900 bg-slate-100 px-2 py-0.5 rounded">{user.affiliateCode}</strong></p>
        </div>
        
        <div className="mt-6 md:mt-0 flex bg-white p-1 rounded-xl shadow-sm border border-slate-200">
           <button 
             onClick={() => setActiveTab('overview')}
             className={`flex items-center px-4 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'overview' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-500 hover:text-slate-900'}`}
           >
             <LayoutDashboard className="w-4 h-4 mr-2" /> Visão Geral
           </button>
           <button 
             onClick={() => setActiveTab('market')}
             className={`flex items-center px-4 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'market' ? 'bg-primary text-white shadow-md' : 'text-slate-500 hover:text-slate-900'}`}
           >
             <Store className="w-4 h-4 mr-2" /> Mercado de Afiliação
           </button>
        </div>
      </div>

      {activeTab === 'overview' ? (
        <div className="animate-fade-in space-y-8">
            <div className="bg-gradient-to-r from-slate-900 to-slate-800 rounded-3xl p-8 text-white shadow-xl flex flex-col md:flex-row items-center justify-between">
                <div>
                    <p className="text-slate-400 font-medium mb-1">Saldo Disponível</p>
                    <h2 className="text-5xl font-extrabold mb-4">R$ {user.balance.toFixed(2)}</h2>
                </div>
                <div>
                    <button 
                        onClick={handleWithdraw}
                        disabled={user.balance === 0 || withdrawing}
                        className="bg-green-500 text-white px-8 py-4 rounded-xl font-bold hover:bg-green-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-lg flex items-center"
                    >
                        {withdrawing ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <DollarSign className="w-5 h-5 mr-2" />}
                        {withdrawing ? 'Processando...' : 'Solicitar Saque'}
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <StatCard icon={<MousePointer className="text-blue-600" />} label="Cliques" value={affiliateStats.clicks} color="bg-blue-50" />
                <StatCard icon={<ShoppingBag className="text-purple-600" />} label="Vendas" value={affiliateStats.sales} color="bg-purple-50" />
                <StatCard icon={<TrendingUp className="text-green-600" />} label="Ganhos Totais" value={`R$ ${affiliateStats.earnings.toFixed(2)}`} color="bg-green-50" />
            </div>
            
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200">
                <h2 className="text-xl font-bold text-slate-900 mb-2">Link Geral da Loja</h2>
                <div className="flex flex-col sm:flex-row gap-3">
                    <input type="text" readOnly value={`${window.location.origin}/#/shop?ref=${user.affiliateCode}`} className="flex-1 p-4 bg-slate-50 rounded-xl border border-slate-200 text-slate-600 font-mono text-sm outline-none" />
                    <button onClick={handleCopyStoreLink} className="bg-slate-900 text-white px-6 py-4 rounded-xl font-semibold hover:bg-primary transition-colors">Copiar</button>
                </div>
            </div>
        </div>
      ) : (
        <div className="animate-fade-in space-y-6">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex flex-col md:flex-row justify-between items-center gap-4">
               <div>
                  <h2 className="text-xl font-bold text-slate-900">Produtos para Afiliar</h2>
                  <p className="text-slate-500 text-sm">Escolha produtos e gere links exclusivos.</p>
               </div>
               <div className="relative w-full md:w-80">
                  <input type="text" placeholder="Buscar..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-primary" />
                  <Search className="w-5 h-5 text-slate-400 absolute left-3 top-3.5" />
               </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
               {filteredProducts.map(product => {
                  const isAffiliated = affiliatedProducts.includes(product.id.toString());
                  const commission = (product.price * 0.10).toFixed(2);
                  const deepLink = generateDeepLink(product.id);

                  return (
                    <div key={product.id} className="bg-white rounded-2xl border border-slate-200 overflow-hidden hover:shadow-lg transition-all flex flex-col">
                        <div className="p-4 flex items-center space-x-4 border-b border-slate-50">
                            <img src={product.image} alt={product.name} className="w-16 h-16 rounded-lg object-cover bg-slate-100" />
                            <div className="flex-1 min-w-0">
                                <h3 className="font-bold text-slate-900 truncate">{product.name}</h3>
                                <p className="text-xs text-slate-500 uppercase">{product.category}</p>
                            </div>
                        </div>
                        
                        <div className="p-4 flex-1">
                            <div className="flex justify-between items-center mb-4 bg-green-50 p-3 rounded-lg border border-green-100">
                                <span className="text-xs font-bold text-green-700 uppercase">Comissão (10%)</span>
                                <span className="font-extrabold text-green-700 text-lg">R$ {commission}</span>
                            </div>
                            <div className="flex justify-between text-sm text-slate-500 mb-2">
                                <span>Preço:</span>
                                <span className="font-medium text-slate-900">R$ {product.price.toFixed(2)}</span>
                            </div>
                        </div>

                        <div className="p-4 pt-0 mt-auto">
                            {!isAffiliated ? (
                                <button 
                                    onClick={() => handleRequestAffiliation(product.id)}
                                    disabled={loadingAffiliations}
                                    className="w-full bg-slate-900 text-white py-3 rounded-xl font-bold hover:bg-primary transition-colors shadow-lg shadow-slate-900/10 flex justify-center items-center disabled:opacity-70"
                                >
                                    {loadingAffiliations ? <Loader2 className="animate-spin w-4 h-4" /> : 'Solicitar Afiliação'}
                                </button>
                            ) : (
                                <div className="space-y-3 animate-fade-in">
                                    <div className="bg-green-100 text-green-700 text-xs font-bold px-3 py-2 rounded-lg flex items-center justify-center">
                                        <CheckCircle className="w-4 h-4 mr-1" /> Aprovado
                                    </div>
                                    <div className="flex gap-2">
                                        <input type="text" readOnly value={deepLink} className="flex-1 text-xs bg-slate-50 border border-slate-200 rounded-lg px-2 text-slate-500 truncate" />
                                        <button onClick={() => copyDeepLink(deepLink)} className="bg-primary text-white p-2 rounded-lg hover:bg-indigo-700">
                                            <Copy className="w-4 h-4" />
                                        </button>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                  );
               })}
            </div>
            
            {filteredProducts.length === 0 && (
                <div className="text-center py-12">
                    <p className="text-slate-500">Nenhum produto encontrado. Clique em "Resetar DB" no Admin se estiver vazio.</p>
                </div>
            )}
        </div>
      )}
    </div>
  );
};

const StatCard = ({ icon, label, value, color }: any) => (
    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div className="flex justify-between items-start mb-4">
            <div className={`p-3 rounded-xl ${color}`}>
                {React.cloneElement(icon, { className: `w-6 h-6 ${icon.props.className}` })}
            </div>
            <span className="text-xs font-medium bg-slate-100 px-2 py-1 rounded text-slate-600">{label}</span>
        </div>
        <p className="text-3xl font-extrabold text-slate-900">{value}</p>
    </div>
);