import { Product } from './types';

export const PRODUCTS: Product[] = [
  {
    id: 1,
    name: "UltraBook Pro X1",
    price: 4500.00,
    oldPrice: 5200.00,
    category: "Notebooks",
    image: "https://picsum.photos/id/1/600/600",
    description: "Potência e portabilidade com processador de última geração, 16GB RAM e SSD de 1TB.",
    rating: 4.8,
    badge: "Oferta"
  },
  {
    id: 2,
    name: "Smartphone Galaxy Zen",
    price: 2999.90,
    category: "Smartphones",
    image: "https://picsum.photos/id/2/600/600",
    description: "Câmera de 108MP, tela AMOLED 120Hz e bateria para o dia todo.",
    rating: 4.6,
    badge: "Lançamento"
  },
  {
    id: 3,
    name: "Fone NoiseCancel 3000",
    price: 899.00,
    oldPrice: 1100.00,
    category: "Áudio",
    image: "https://picsum.photos/id/3/600/600",
    description: "Isolamento acústico ativo, som de alta fidelidade e conforto premium.",
    rating: 4.5,
    badge: "-20%"
  },
  {
    id: 4,
    name: "Smartwatch FitLife",
    price: 650.00,
    category: "Wearables",
    image: "https://picsum.photos/id/4/600/600",
    description: "Monitore sua saúde, exercícios e sono com precisão.",
    rating: 4.2
  },
  {
    id: 5,
    name: "Teclado Mecânico RGB",
    price: 350.00,
    category: "Periféricos",
    image: "https://picsum.photos/id/5/600/600",
    description: "Switches azuis táteis, iluminação RGB customizável e durabilidade extrema.",
    rating: 4.7
  },
  {
    id: 6,
    name: "Monitor UltraWide 34\"",
    price: 2200.00,
    oldPrice: 2800.00,
    category: "Monitores",
    image: "https://picsum.photos/id/6/600/600",
    description: "Imersão total para jogos e produtividade com resolução 4K.",
    rating: 4.9,
    badge: "Top Seller"
  },
  {
    id: 7,
    name: "Mouse Gamer Precision",
    price: 250.00,
    category: "Periféricos",
    image: "https://picsum.photos/id/7/600/600",
    description: "20.000 DPI, peso ajustável e 8 botões programáveis.",
    rating: 4.4
  },
  {
    id: 8,
    name: "Tablet ProCreate 11",
    price: 3200.00,
    category: "Tablets",
    image: "https://picsum.photos/id/8/600/600",
    description: "Perfeito para designers e ilustradores, compatível com caneta stylus.",
    rating: 4.8
  }
];

export const CATEGORIES = ["Todos", "Notebooks", "Smartphones", "Áudio", "Wearables", "Periféricos", "Monitores", "Tablets"];