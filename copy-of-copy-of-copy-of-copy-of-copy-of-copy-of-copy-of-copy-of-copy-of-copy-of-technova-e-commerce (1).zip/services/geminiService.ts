import { GoogleGenAI } from "@google/genai";
import { PRODUCTS } from '../constants';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getChatResponse = async (userMessage: string): Promise<string> => {
  try {
    const productContext = PRODUCTS.map(p => `${p.name} ($${p.price}) - ${p.description}`).join("\n");
    
    const systemInstruction = `Você é um assistente de vendas virtual da TechNova, um e-commerce de tecnologia.
    Seja educado, prestativo e conciso. Ajude o cliente a escolher produtos.
    
    Aqui está a lista de produtos disponíveis na loja:
    ${productContext}
    
    Se o usuário perguntar sobre algo que não vendemos, diga que infelizmente não temos, mas sugira algo similar se houver.
    Responda sempre em Português do Brasil.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: userMessage,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7,
      }
    });

    return response.text || "Desculpe, não consegui processar sua solicitação no momento.";
  } catch (error) {
    console.error("Erro ao chamar Gemini:", error);
    return "Estou tendo dificuldades técnicas. Por favor, tente novamente mais tarde.";
  }
};
